package com.example.zadanie2;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        Testing test = new Testing();
        for(int i=0;i<5;i++) test.tests();
    }
}
//nemozu byt duplikaty