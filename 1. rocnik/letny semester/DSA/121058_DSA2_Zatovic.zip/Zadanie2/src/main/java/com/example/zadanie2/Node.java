package com.example.zadanie2;

public class Node {
    Node left_child;
    Node right_child;
    Node parent;
    String funkcia;
    String index;
    public Node(String funkcia){
        this.funkcia=funkcia;
    }
}
