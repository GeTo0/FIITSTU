#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define DATA_S 20

typedef struct node {
    float key;
    char data[DATA_S];
    struct node *next;
} NODE;

int hashhodnota(char *input, int *tablesize) {
    int value = 0, g=31;
    for (int i = 0; i < DATA_S; i++) {
        if ((input)[i] != ('\n')) {
            value = ((g*value)+input[i])%(*tablesize);
        } else break;
    }
    return value;
}

void resizetableM(int *tablesize, NODE ***table) {
    int newtablesize = *tablesize << 1; //nová tabuľka bude mat dvojnasobnu velkost vdaka bitovemu posunu o 1 miesto
    NODE **newtable = (NODE **) malloc(newtablesize * (sizeof(NODE *)));//Vytvorenie novej tabulky
    for (int i = 0; i < newtablesize; i++) {
        newtable[i] = (NODE *) malloc(sizeof(NODE));
        newtable[i] = NULL;
    }
    for (int i = 0; i < (*tablesize); i++) {//prejdeme kazdy index v starej tabulke
        NODE *current = (*table)[i];
        while (current != NULL) {//ak sa na danom indexe nachadzaju nejake data
            int pozicia = hashhodnota(current->data, &newtablesize);//vypocita poziciu v novej tabulke, kam zapiseme data
            if ((newtable[pozicia]) == NULL) {//ak sa na novej pozicii nic nenachadza
                NODE *novy = (NODE *) malloc(sizeof(NODE));
                strncpy(novy->data, current->data, DATA_S);
                novy->key = current->key;
                novy->next = NULL;
                newtable[pozicia] = novy;

            } else {//ak sa tam uz nieco nachadza
                NODE *prechadzam = newtable[pozicia];
                while (prechadzam->next != NULL) {//prechadzam linked list kym sa nedostanem na posledny prvok
                    prechadzam = prechadzam->next;
                }
                NODE *novy = (NODE *) malloc(sizeof(NODE));//vytvorim novu nodu a zapisem do nej data
                strncpy(novy->data, current->data, DATA_S);
                novy->key = current->key;
                novy->next = NULL;
                prechadzam->next = novy;//nas posledny prvok listu bude ukazovat na novy
            }
            current = current->next;
        }
    }
    *tablesize = newtablesize;//nasu globalnu premennu velkost tabulky zmenim na velkost novej tabulky
    **table = (NODE **) malloc(newtablesize * (sizeof(NODE *)));//na adresu ,kde som mal staru tabulku, treba priradit novu pamat na novu tabulku
    *table = newtable;//na adresu starej tabulky zapisem novu tabulku
}

void resizetableL(int *tablesize, NODE ***table)
{
    int newtablesize = *tablesize >> 1;
    NODE **newtable = (NODE **) malloc(newtablesize * (sizeof(NODE *)));
    for (int i = 0; i < newtablesize; i++) {
        newtable[i] = (NODE *) malloc(sizeof(NODE));
        newtable[i] = NULL;
    }
    for (int i = 0; i < (*tablesize); i++) {
        NODE *current = (*table)[i];
        while (current != NULL) {
            int pozicia = hashhodnota(current->data, &newtablesize);
            if ((newtable[pozicia]) == NULL) {
                NODE *novy = (NODE *) malloc(sizeof(NODE));
                strncpy(novy->data, current->data, DATA_S);
                novy->key = current->key;
                novy->next = NULL;
                newtable[pozicia] = novy;

            } else {
                NODE *prechadzam = newtable[pozicia];
                while (prechadzam->next != NULL) {
                    prechadzam = prechadzam->next;
                }
                NODE *novy = (NODE *) malloc(sizeof(NODE));
                strncpy(novy->data, current->data, DATA_S);
                novy->key = current->key;
                novy->next = NULL;
                prechadzam->next = novy;
            }
            current = current->next;
        }
    }
    *tablesize = newtablesize;
    for (int i = 0; i < *tablesize; i++) {
        free((*table)[i]);
        (*table)[i]=NULL;
    }
    **table = (NODE **) malloc(newtablesize * (sizeof(NODE *)));
    *table = newtable;
}

int checktablesize(int *counter, int *tablesize) {
    float hodnota = (float) *counter;
    float ts = (float) *tablesize;
    if (hodnota > 0.75 * ts) return 0;
    else if (hodnota < 0.2 * ts) return -5;
    else return 1;
}

void insert(int *tablesize, int *counter, NODE ***table, char *input, float *key) {
    int pozicia = hashhodnota(input, tablesize);//zistenie indexu, na ktory dame data
    NODE *current = (*table)[pozicia];

    if ((current) == NULL) {//tak sa na indexe ešte nič nenachadza
        current = (NODE *) malloc(sizeof(NODE));
        strncpy(current->data, input, DATA_S);
        current->key = *key;
        current->next = NULL;
        (*table)[pozicia] = current;
    } else {//ak sa na indexe niečo nachadza
        while (1) {
            if ((current->next == NULL) || (strcmp(current->data, input) == 0)) {//prechadzame prvky kym sa nedostaneme na koniec linked listu
                break;
            }
            current = current->next;
        }
        if (strcmp(current->data, input) == 0) {//ak sa v tabuľke už nachadza rovnaký prvok ale s inou hodnotou, tak ho prepíšeme na nový
            strncpy(current->data, input, DATA_S);
            current->key = *key;
            current->next = NULL;
        } else if (current->next == NULL) {//ak sme došli na koniec listu, tak tam dáme náš nový prvok
            NODE *novy = (NODE *) malloc(sizeof(NODE));
            strncpy(novy->data, input, DATA_S);
            novy->key = *key;
            novy->next = NULL;
            current->next = novy;
        }

    }
    (*counter)++;
}

void search(int *tablesize, NODE ***table, char *hladany) {
    int pozicia = hashhodnota(hladany, tablesize),najdeny=0;
    NODE *current = (*table)[pozicia];

    if (current == NULL);
    else {
        while (current != NULL) {
            if (strcmp((current->data), hladany) == 0) {
                break;
            }
            current = current->next;
        }
    }
}

void delete(int *tablesize, NODE ***table, int *counter, char *hladany) {
    int pozicia = hashhodnota(hladany, tablesize);//zistenie indexu v tabulke
    NODE *current = (*table)[pozicia];
    NODE *docasny;
    if (current == NULL);
    else {
        if (current->next == NULL) {/*hladany prvok je jediny na danom mieste v poli (nema nasledovnikov)*/
            free(current);
            current = NULL;
            (*table)[pozicia] = NULL;
        } else if (current->next != NULL) {/*prvok neni jediny*/
            int poradie = 0;
            while (strcmp((current->data), hladany) !=0) {/*ideme v cykle kym sa nedostaneme na prvok, ktory chceme vymazat, pritom pocitam, kolki v poradi je*/
                docasny = current;
                current = current->next;
                poradie++;
            }
            if (current->next == NULL) {/*ak uz nema nasledovnika, vymazem ho a predosly prvok bude ukazovat na NULL*/
                free(current);
                current = NULL;
                docasny->next = NULL;

            } else if ((current->next != NULL) && (poradie == 0)) {/*ak ma nasledovnika a je uplne na zaciatku*/
                (*table)[pozicia] = current->next;
                free(current);
                current = NULL;

            } else if ((current->next != NULL) && (poradie != 0)) {/*ak ma nasledovnika a neni na zaciatku*/
                docasny->next = current->next;
                free(current);
                current = NULL;
            }
        }
        int hodnota = checktablesize(&(*counter), &(*tablesize));
        if (hodnota == -5) {
            resizetableL(&(*tablesize), &(*table));
        }
    }
    (*counter)--;
}

int main() {
    float key;
    char value[DATA_S];
    char keych[DATA_S];
    FILE *f = NULL;
    FILE *v = NULL;
    v = fopen("vysledkytestov.txt", "w");
    int tablesize, counter = 0;
    int hodnota;
    NODE **table;

    for (int i = 0; i < 7; i++) {
        if (i == 0) {
            f = fopen("TESTS10.txt", "r");
            fprintf(v, "Testujeme 10 prvkov v subore\n");
            tablesize = 16;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        } else if (i == 1) {
            f = fopen("TESTS100.txt", "r");
            fprintf(v, "Testujeme 100 prvkov v subore\n");
            tablesize = 64;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        } else if (i == 2) {
            f = fopen("TESTS1000.txt", "r");
            fprintf(v, "Testujeme 1000 prvkov v subore\n");
            tablesize = 1028;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        } else if (i == 3) {
            f = fopen("TESTS10000.txt", "r");
            fprintf(v, "Testujeme 10000 prvkov v subore\n");
            tablesize = 8192;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        } else if (i == 4) {
            f = fopen("TESTS100000.txt", "r");
            fprintf(v, "Testujeme 100000 prvkov v subore\n");
            tablesize = 65536;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        } else if (i == 5) {
            f = fopen("TESTS1000000.txt", "r");
            fprintf(v, "Testujeme 1000000 prvkov v subore\n");
                tablesize = 1048576;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        } else if (i == 6) {
            f = fopen("TESTS10000000.txt", "r");
            fprintf(v, "Testujeme 10000000 prvkov v subore\n");
            tablesize = 8388608;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        }
        if (f == NULL) {
            fprintf(v, "Neotvoreny subor\n");
        } else {
            for (int k = 0; k < 3; k++) {
                clock_t start_time = clock();
                if (k == 0) {
                    fprintf(v, "Insert-Search\n");
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        key = atof(keych);
                        insert(&tablesize, &counter, (NODE ***) &table, &value, &key);
                        hodnota = checktablesize(&counter, &tablesize);
                        if (hodnota == 0) {
                            resizetableM(&tablesize, (NODE ***) &(table));
                        }
                    }
                    rewind(f);

                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        search(&tablesize, &table, &value);
                    }

                    clock_t end_time = clock();
                    double duration = (double) (end_time - start_time) / CLOCKS_PER_SEC;
                    fprintf(v, "Dlzka programu bola: %f sekund\n", duration);
                    rewind(f);
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        delete(&tablesize, &table, &counter, &value);
                    }
                    rewind(f);
                }

                if (k == 1) {
                    fprintf(v,"Insert-Delete\n");
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        key=atof(keych);
                        insert(&tablesize, &counter, (NODE ***) &table,&value,&key);
                        hodnota = checktablesize(&counter, &tablesize);
                        if (hodnota == 0) {
                            resizetableM(&tablesize, (NODE ***) &(table));
                        }
                    }
                    rewind(f);
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        delete(&tablesize, &table, &counter,&value);
                    }
                    clock_t end_time = clock();
                    double duration = (double) (end_time - start_time) / CLOCKS_PER_SEC;
                    fprintf(v,"Dlzka programu bola: %f sekund\n", duration);
                }
                if (k == 2) {
                    fprintf(v,"Insert-Search-Delete\n");
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        key=atof(keych);
                        insert(&tablesize, &counter, (NODE ***) &table,&value,&key);
                        hodnota = checktablesize(&counter, &tablesize);
                        if (hodnota == 0) {
                            resizetableM(&tablesize, (NODE ***) &(table));
                        }
                    }
                    rewind(f);
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        search(&tablesize, &table,&value);
                    }
                    rewind(f);
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        delete(&tablesize, &table, &counter,&value);
                    }
                    clock_t end_time = clock();
                    double duration = (double) (end_time - start_time) / CLOCKS_PER_SEC;
                    fprintf(v,"Dlzka programu bola: %f sekund\n\n\n", duration);
                }
                rewind(f);
            }
        }
            fclose(f);
    }
    fclose(v);
    return 0;
}