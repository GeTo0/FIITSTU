#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define DATA_S 20

typedef struct node {
    float key;
    char data[DATA_S];
} NODE;

int hashhodnota(char *input, int *tablesize) {
    int value = 0, g = 31;
    for (int i = 0; i < DATA_S; i++) {
        if ((input)[i] != ('\n')) {
            value = ((g * value) + input[i]) % (*tablesize);
        } else break;
    }
    return value;
};

int checktablesize(int *counter, int *tablesize) {
    float hodnota = (float) *counter;
    float ts = (float) *tablesize;
    if (hodnota > 0.75 * ts) return 0;
    else if (hodnota < 0.2 * ts) return -5;
    else return 1;
}

void resizetableM(int *tablesize, NODE ***table) {
    int newtablesize = *tablesize << 1;
    NODE **newtable = (NODE **) malloc(newtablesize * (sizeof(NODE *)));//Vytvorenie novej tabulky
    for (int i = 0; i < newtablesize; i++) {
        newtable[i] = (NODE *) malloc(sizeof(NODE));
        newtable[i] = NULL;
    }
    for (int j = 0; j < *tablesize; j++) {//prechadzam prvky v starej tabulke
        int posun = 0;
        NODE *docasny = (*table)[j];
        if ((docasny != NULL)&&(strcmp(docasny->data,"deleted")!=0)) {//ak sa nachadzaju nejake data na danom indexe
            int pozicia = hashhodnota(docasny->data, &newtablesize);//tak vypocitam ich poziciu v novej tabulke
            NODE *current = newtable[pozicia];
            while (current != NULL) {//ak je index zaplneny, posuvam sa po indexoch ako pri inserte az kym nenajdem volny
                posun++;
                pozicia = (pozicia + (posun * posun)) % (newtablesize);
                current = (newtable)[pozicia];
            }
            if (current == NULL) {//najdem prazdny index, zapisem don hodnotu
                current = (NODE *) malloc(sizeof(NODE));
                strncpy(current->data, (*table)[j]->data, DATA_S);
                current->key = (*table)[j]->key;
                (newtable)[pozicia] = current;
            }
        }
    }
    *tablesize = newtablesize;
    **table = (NODE **) malloc(newtablesize * (sizeof(NODE *)));
    *table = newtable;
}

void resizetableL(int *tablesize, NODE ***table) {
    int newtablesize = *tablesize >> 1;
    NODE **newtable = (NODE **) malloc(newtablesize * (sizeof(NODE *)));
    for (int i = 0; i < newtablesize; i++) {
        newtable[i] = (NODE *) malloc(sizeof(NODE));
        newtable[i] = NULL;
    }
    for (int j = 0; j < *tablesize; j++) {
        int posun = 0;
        NODE *docasny = (*table)[j];
        if ((docasny != NULL)&&(strcmp(docasny->data,"deleted")!=0)) {
            int pozicia = hashhodnota(docasny->data, &newtablesize);
            NODE *current = newtable[pozicia];
            while (current != NULL) {
                posun++;
                pozicia = (pozicia + (posun * posun)) % (newtablesize);
                current = (newtable)[pozicia];
            }
            if (current == NULL) {
                current = (NODE *) malloc(sizeof(NODE));
                strncpy(current->data, (*table)[j]->data, DATA_S);
                current->key = (*table)[j]->key;
                (newtable)[pozicia] = current;
            }
        }
    }
    *tablesize = newtablesize;
    **table = (NODE **) malloc(newtablesize * (sizeof(NODE *)));
    *table = newtable;
}

void insert(int *tablesize, int *counter, NODE ***table, char *input, float *key) {
    int posun = 0;
    int pozicia = hashhodnota(input, tablesize);
    NODE *current = (*table)[pozicia];
    while ((current != NULL) && (strcmp(current->data, "deleted") != 0)) {//kym sa nenajde volna pozicia ale pozicia, na ktorej bol vymazany prvok
        posun++;
        pozicia = (pozicia + (posun * posun)) % (*tablesize);
        current = (*table)[pozicia];
    }
    if (current == NULL) {//ak sa najde volna pozicia, zapise nan udaje
        current = (NODE *) malloc(sizeof(NODE));
        strncpy(current->data, input, DATA_S);
        current->key = *key;
        (*table)[pozicia] = current;
    } else if (strcmp(current->data, "deleted") == 0) {//ak sa najde vymazana pozicia, zapise nan udaje
        strncpy(current->data, input, DATA_S);
        current->key = *key;
        (*table)[pozicia] = current;
    }
    (*counter)++;
}

void search(int *tablesize, NODE ***table, char *hladany) {
    int pozicia = hashhodnota(hladany, tablesize);
    int posun = 0;
    NODE *current = (*table)[pozicia];

    while ((current != NULL) && (strcmp(current->data, hladany) != 0)) {
        posun++;
        pozicia = (pozicia + (posun * posun)) % (*tablesize);
        current = (*table)[pozicia];
    }
}

void delete(int *tablesize, NODE ***table, int *counter, char *hladany) {
    int pozicia = hashhodnota(hladany, tablesize);
    int posun = 0;
    NODE *current = (*table)[pozicia];
    if (current == NULL);
    else {
        while ((strcmp(current->data, hladany) != 0)) {
            posun++;
            pozicia = (pozicia + (posun * posun)) % (*tablesize);
            current = (*table)[pozicia];
        }
        if ((strcmp(current->data, hladany) == 0)) {
            strcpy(current->data, "deleted");
            current->key = 0;
        }
    }
    (*counter)--;
    if (checktablesize(counter, tablesize) == -5) {
        resizetableL(tablesize, table);
    }
}

int main() {
    float key;
    char value[DATA_S];
    char keych[DATA_S];
    FILE *f = NULL;
    FILE *v = NULL;
    v = fopen("vysledkytestov.txt", "w");
    int tablesize, counter = 0;
    int hodnota;
    NODE **table;

    for (int i = 0; i < 7; i++) {
        if (i == 0) {
            f = fopen("TESTS10.txt", "r");
            fprintf(v, "Testujeme 10 prvkov v subore\n");
            tablesize = 16;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        } else if (i == 1) {
            f = fopen("TESTS100.txt", "r");
            fprintf(v, "Testujeme 100 prvkov v subore\n");
            tablesize = 64;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        } else if (i == 2) {
            f = fopen("TESTS1000.txt", "r");
            fprintf(v, "Testujeme 1000 prvkov v subore\n");
            tablesize = 1028;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        } else if (i == 3) {
            f = fopen("TESTS10000.txt", "r");
            fprintf(v, "Testujeme 10000 prvkov v subore\n");
            tablesize = 8192;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        } else if (i == 4) {
            f = fopen("TESTS100000.txt", "r");
            fprintf(v, "Testujeme 100000 prvkov v subore\n");
            tablesize = 65536;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        } else if (i == 5) {
            f = fopen("TESTS1000000.txt", "r");
            fprintf(v, "Testujeme 1000000 prvkov v subore\n");
            tablesize = 1048576;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        } else if (i == 6) {
            f = fopen("TESTS10000000.txt", "r");
            fprintf(v, "Testujeme 10000000 prvkov v subore\n");
            tablesize = 8388608;
            table = (NODE **) malloc(tablesize * (sizeof(NODE *)));
            for (int j = 0; j < tablesize; j++) {
                table[j] = (NODE *) malloc(sizeof(NODE));
                table[j] = NULL;
            }
        }
        if (f == NULL) {
            fprintf(v, "Neotvoreny subor\n");
        } else {
            for (int k = 0; k < 3; k++) {
                clock_t start_time = clock();
                if (k == 0) {
                    fprintf(v, "Insert-Search\n");
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        key = atof(keych);
                        insert(&tablesize, &counter, (NODE ***) &table, &value, &key);
                        hodnota = checktablesize(&counter, &tablesize);
                        if (hodnota == 0) {
                            resizetableM(&tablesize, (NODE ***) &(table));
                        }
                    }
                    rewind(f);

                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        search(&tablesize, &table, &value);
                    }

                    clock_t end_time = clock();
                    double duration = (double) (end_time - start_time) / CLOCKS_PER_SEC;
                    fprintf(v, "Dlzka programu bola: %f sekund\n", duration);
                    rewind(f);
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        delete(&tablesize, &table, &counter, &value);
                    }
                    rewind(f);
                }

                if (k == 1) {
                    fprintf(v, "Insert-Delete\n");
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        key = atof(keych);
                        insert(&tablesize, &counter, (NODE ***) &table, &value, &key);
                        hodnota = checktablesize(&counter, &tablesize);
                        if (hodnota == 0) {
                            resizetableM(&tablesize, (NODE ***) &(table));
                        }
                    }
                    rewind(f);
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        delete(&tablesize, &table, &counter, &value);
                    }
                    clock_t end_time = clock();
                    double duration = (double) (end_time - start_time) / CLOCKS_PER_SEC;
                    fprintf(v, "Dlzka programu bola: %f sekund\n", duration);
                }

                if (k == 2) {
                    fprintf(v, "Insert-Search-Delete\n");
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        key = atof(keych);
                        insert(&tablesize, &counter, (NODE ***) &table, &value, &key);
                        hodnota = checktablesize(&counter, &tablesize);
                        if (hodnota == 0) {
                            resizetableM(&tablesize, (NODE ***) &(table));
                        }
                    }
                    rewind(f);
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        search(&tablesize, &table, &value);
                    }
                    rewind(f);
                    while ((fgets(keych, DATA_S, f)) != NULL) {
                        fgets(value, DATA_S, f);
                        delete(&tablesize, &table, &counter, &value);
                    }
                    clock_t end_time = clock();
                    double duration = (double) (end_time - start_time) / CLOCKS_PER_SEC;
                    fprintf(v, "Dlzka programu bola: %f sekund\n\n\n", duration);
                }
                rewind(f);
            }
        }
        fclose(f);
    }
    fclose(v);
    return 0;
}