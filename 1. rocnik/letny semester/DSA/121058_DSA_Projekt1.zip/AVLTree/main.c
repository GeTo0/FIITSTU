#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define CISLO_V 10
#define INFO_V 20

typedef struct node {
    int cislo;
    int height;
    char informacia[INFO_V];
    struct node *n_p;
    struct node *n_l;
} NODE;

int max(int a,int b) { //Zisti vacsiu hodnotu z 2 cisel, v nasom pripade pouzite na zistenie height nody (ci ma viac nod vpravo alebo vlavo)
    return (a > b) ? a : b;
}

int height(NODE *test) {//pomocna funkcia na height
    if (test == NULL)
        return 0;
    return test->height;
}

NODE *LR(NODE *problem) {//rotacia vlavo
    NODE *docasna = problem->n_p;
    NODE *doc2 = docasna->n_l;

    docasna->n_l = problem;
    problem->n_p = doc2;

    problem->height = max(height(problem->n_l), height(problem->n_p)) + 1;
    docasna->height = max(height(docasna->n_l), height(docasna->n_p)) + 1;

    return docasna;
}

NODE *RR(NODE *problem) { // rotacia vpravo
    NODE *docasna = problem->n_l;
    NODE *doc2 = docasna->n_p;

    docasna->n_p = problem;
    problem->n_l = doc2;

    problem->height = max(height(problem->n_l), height(problem->n_p)) + 1;
    docasna->height = max(height(docasna->n_l), height(docasna->n_p)) + 1;

    return docasna;

}

int getBalance(NODE *test) { //zistenie balancu danej nody
    if (test == NULL)
        return 0;
    return height(test->n_l) - height(test->n_p);
}

NODE *NewNode(int input, char *value) { //Vytvorenie novej nody
    NODE *novy = (NODE *) malloc(sizeof(NODE));
    novy->cislo = input;
    strncpy(novy->informacia, value, INFO_V);
    novy->n_l = NULL;
    novy->n_p = NULL;
    novy->height = 1;
    return (novy);
}

NODE *insert(NODE *teraz, int input,char *value) {//rekurzivna funkcia, insertnem nodu na dane miesto, potom sa bude vraciat smerom napspat k head a upravovat balance, nakonci returne najvyssiu nodu ako head
    if (teraz == NULL) // ak najde poziciu kam ma dat novu nodu, tak ju tam vytvori
        return (NewNode(input, value));

    if (input < teraz->cislo) //ak nenajde, tak sa posunie podla toho ci je mensie, vacsie
        teraz->n_l = insert(teraz->n_l, input, value);
    else if (input > teraz->cislo)
        teraz->n_p = insert(teraz->n_p, input, value);
    else
        return teraz;//Ak uz v mojom TREE existuje rovnake cislo, tak je to zle.

    teraz->height = 1 + max(height(teraz->n_l),
                            height(teraz->n_p));//ako bude prechadzat jednotlive nody, tak to balancne strom so zapocitanim novej nody ktoru idem pridat

    int balance = getBalance(teraz);//zistime či je noda balancnuta

    if (balance > 1 && input < teraz->n_l->cislo)//ak je noda nebalancnuta a nasa nova noda je mensia ako lavy child, spravime Right-Rotation rotaciu
        return RR(teraz);// child noda nalavo sa stane novou parent nodou, jej prvok vlavo sa zachova a vpravo sa da stary parent node

    if (balance > 1 && input > teraz->n_l->cislo) {//kombinacia LR a RR
        teraz->n_l = LR(teraz->n_l);
        return RR(teraz);
    }

    if (balance < -1 && input > teraz->n_p->cislo)//noda nebalancnuta, nasa nova noda je vacsia ako child napravo,tak child napravo bude nova parent
        return LR(teraz);//nas stary parent bude lavy child od noveho parenta, pravy child tohto bude lavy child co mal novy parent

    if (balance < -1 && input < teraz->n_p->cislo) {//kombinacia RR a LR
        teraz->n_p = RR(teraz->n_p);
        return LR(teraz);
    }
    return teraz;//nakonci insertu nam to vrati head prvok (totalny parent, nema dalsich parentov)
}

void search(NODE *head, int hladane) {
    NODE *teraz;
    teraz = head;
    while (teraz!=NULL) {
        if (hladane == (teraz->cislo)) {
            break;
        } else if (hladane > (teraz->cislo)) {
            teraz = teraz->n_p;
        } else if (hladane < (teraz->cislo)) {
            teraz = teraz->n_l;
        }
    }
}

NODE *forChange(NODE *change) {//musim najst najmensi prvok v pravom subtree od nody ktoru chcem deletnut, lebo ak ju zamenim za tu, co chcem vymazat, tak sa zachova to ze napravo od nej budu cisla vyssie a nalavo nizsie
    NODE *teraz = change;
    while (teraz->n_l != NULL)
        teraz = teraz->n_l;
    return teraz;
}

NODE *delete(NODE *teraz, int problem) {//rekurzivna funkcia na nájdenie nody na vymazanie a následne vybalancovanie stromu
    if (teraz == NULL) //znamena ze nie je ziadny root, tym padom sa neda nic deletnut
        return teraz;

    if (problem < teraz->cislo) //ak je hladane cislo mensie, ideme doprava, ak vacsie, tak dolava
        teraz->n_l = delete(teraz->n_l, problem);

    else if (problem > teraz->cislo)
        teraz->n_p = delete(teraz->n_p, problem);

    else { //ak sme sa dostali na nodu ktoru treba deletnut
        if ((teraz->n_l == NULL) || (teraz->n_p == NULL)) {//zistime na ktorej strane sa nachadza dalsia noda, ktorou nahradime tu co vymazavame
            NODE *temp = teraz->n_l ? teraz->n_l
                                    : teraz->n_p; //do tempu ulozime nodu ktora sa nachadza pod nasou co ideme vymazat

            if (temp == NULL) {//ak sa pod nasou nodou nenachadza dalsia, tak ju jednoducho vymazem
                teraz = NULL;
                free(temp);
                free(teraz);

            } else //ak sa pod nasou nodou nachadza dalsia, tak terajsiu zmenim na dalsiu
                *teraz = *temp;
            free(temp);

        } else {//ak sa pod nasou nodou na oboch stranach nachadza dalsia noda
            NODE *temp = forChange(
                    teraz->n_p);//zistime ktora noda je poslednym nastupcom v pravom subtree a tym nahradime nasu terajsiu

            teraz->cislo = temp->cislo;
            strncpy(teraz->informacia,temp->informacia,INFO_V);

            teraz->n_p = delete(teraz->n_p, temp->cislo);//rekurziou sa dostanem na prvok, ktorý nam našla funckia forChange a musím ho vymazať, keďźe som ho premiestnil navrch (možno má pravého childa)
        }
    }
    if (teraz == NULL) //ak to nenaslo taku nodu, ktoru chcem deletnut
        return teraz;

    teraz->height = 1 + max(height(teraz->n_l),//rekurziou ideme naspat smerom k head a budeme upravovat balance, tak ako v inserte
                            height(teraz->n_p));

    int balance = getBalance(teraz);

    if (balance > 1 && getBalance(teraz->n_l) >= 0)
        return RR(teraz);

    if (balance > 1 && getBalance(teraz->n_l) < 0) {
        teraz->n_l = LR(teraz->n_l);
        return RR(teraz);
    }

    if (balance < -1 && getBalance(teraz->n_p) <= 0)
        return LR(teraz);

    if (balance < -1 && getBalance(teraz->n_p) > 0) {
        teraz->n_p = RR(teraz->n_p);
        return LR(teraz);
    }

    return teraz;//nakonci mi returne najvyssi prvok (root) ako head
}

int main() {
    NODE *head = NULL;
    int input = 0;
    char slovo[10];
    char value[INFO_V];
    FILE *f = NULL;
    FILE *v=NULL;
    FILE *t=NULL;
    v=fopen("vysledkytestov.txt","w");

    for (int i = 0; i < 7; i++) {
        if (i == 0) {
            f = fopen("TESTS10.txt", "r");
            fprintf(v,"Testujeme 10 prvkov v subore\n");
        }
        if (i == 1) {
            f = fopen("TESTS100.txt", "r");
            fprintf(v,"Testujeme 100 prvkov v subore\n");
        }
        if (i == 2) {
            f = fopen("TESTS1000.txt", "r");
            fprintf(v,"Testujeme 1000 prvkov v subore\n");
        }
        if (i == 3) {
            f = fopen("TESTS10000.txt", "r");
            fprintf(v,"Testujeme 10000 prvkov v subore\n");
        }
        if (i == 4) {
            f = fopen("TESTS100000.txt", "r");
            fprintf(v,"Testujeme 100000 prvkov v subore\n");
        }
        if (i == 5) {
            f = fopen("TESTS1000000.txt", "r");
            fprintf(v,"Testujeme 1000000 prvkov v subore\n");
        }
        if (i == 6) {
            f = fopen("TESTS10000000.txt", "r");
            fprintf(v,"Testujeme 10000000 prvkov v subore\n");
        }
        if (f == NULL) {
            fprintf(v,"Neotvoreny subor\n");
        } else {
            for (int j = 0; j < 3; j++) {
                clock_t start_time = clock();
                if (j == 0) {
                    fprintf(v,"Insert-Search\n");
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        head = insert(head, input, value);
                    }
                    rewind(f);
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        search(head, input);
                    }
                    clock_t end_time = clock();
                    double duration = (double) (end_time - start_time) / CLOCKS_PER_SEC;
                    fprintf(v,"Dlzka programu bola: %f sekund\n", duration);
                    rewind(f);
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        head = delete(head, input);
                    }
                }
                if (j == 1) {
                    fprintf(v,"Insert-Delete\n");
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        head = insert(head, input, value);
                    }
                    rewind(f);
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        head = delete(head, input);
                    }
                    clock_t end_time = clock();
                    double duration = (double) (end_time - start_time) / CLOCKS_PER_SEC;
                    fprintf(v,"Dlzka programu bola: %f sekund\n", duration);
                }
                if (j == 2) {
                    fprintf(v,"Insert-Search-Delete\n");
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        head = insert(head, input, value);
                    }
                    rewind(f);
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        search(head, input);
                    }
                    rewind(f);
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        head = delete(head, input);
                    }
                    clock_t end_time = clock();
                    double duration = (double) (end_time - start_time) / CLOCKS_PER_SEC;
                    fprintf(v,"Dlzka programu bola: %f sekund\n\n\n", duration);
                }
                rewind(f);
            }
            fclose(f);
        }
    }
    fclose(v);
    return 0;
}