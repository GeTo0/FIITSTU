#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define INFO_V 20

typedef struct node {
    int cislo;
    char informacia[INFO_V];
    struct node *n_p;
    struct node *n_l;
} NODE;

NODE *NewNode(int input, char *value) { //Vytvorenie novej nody
    NODE *novy = (NODE *) malloc(sizeof(NODE));
    novy->cislo = input;
    strncpy(novy->informacia, value, INFO_V);
    novy->n_l = NULL;
    novy->n_p = NULL;
    return (novy);
}

NODE *RotateRight(NODE *x) {
    NODE *y;
    y = x->n_l;
    x->n_l = y->n_p;
    y->n_p = x;
    return (y);
}

NODE *RotateLeft(NODE *y) {
    NODE *x;
    x = y->n_p;
    y->n_p = x->n_l;
    x->n_l = y;
    return (x);
}

NODE *splay(NODE *head, int input) {
    if ((head == NULL) || (head->cislo == input))//nemame head alebo nase hladane cislo je head
        return head;

    if (input < head->cislo) {//hladane cislo je mensie ako head
        if (head->n_l == NULL) return head; //hladane cislo neni v strome

        if (input < head->n_l->cislo) {//LEFT-LEFT rotácia
            head->n_l->n_l = splay(head->n_l->n_l, input);
            head = RotateRight(head);

        } else if (input > head->n_l->cislo) {//LEFT-RIGHT rotácia
            head->n_l->n_p = splay(head->n_l->n_p, input);
            if (head->n_l->n_p != NULL)
                head->n_l = RotateLeft(head->n_l);
        }
        if (head->n_l == NULL)
            return head; //nas input ma vzdy child NULL, cize na konci zistime ci uz nas input je ako head vdaka tomuto, ak nie, tak spravim dalsiu rotaciu
        else return RotateRight(head); //nasa hladana noda je child aktualneho headu

    } else //hladane cislo je vacsie ako head
    {
        if (head->n_p == NULL) return head;//hladane cislo nie je v strome

        if (input > head->n_p->cislo) {//RIGHT-RIGHT rotacia
            head->n_p->n_p = splay(head->n_p->n_p, input);
            head = RotateLeft(head);

        } else if (input < head->n_p->cislo) {//RIGHT-LEFT rotácia
            head->n_p->n_l = splay(head->n_p->n_l, input);
            if (head->n_p->n_l != NULL)
                head->n_p = RotateRight(head->n_p);
        }
        if (head->n_p == NULL)
            return head;//to iste ako vyssie, nasa noda uz je head
        else return RotateLeft(head);//hladana noda je child aktualneho headu
    }
}

NODE *insert(NODE *teraz, int input, char *value) {
    if (teraz == NULL) // ak najde poziciu kam ma dat novu nodu, tak ju tam vytvori
        return (NewNode(input,value));

    if (input < teraz->cislo) //ak nenajde, tak sa posunie podla toho ci je mensie, vacsie
        teraz->n_l = insert(teraz->n_l, input,value);
    else if (input > teraz->cislo)
        teraz->n_p = insert(teraz->n_p, input,value);
    else
        return teraz;//Ak uz v mojom TREE existuje rovnake cislo, tak je to zle.
    return teraz;
}

NODE *biggestR(NODE *change) {//musim najst najvacsu prvok v pravom subtree a ten prvok bude nas novy head
    NODE *teraz = change;
    while (teraz->n_p != NULL)
        teraz = teraz->n_p;
    return teraz;
}


NODE *delete(NODE *head,int input) {//prvok ktory chcem vymazat dostanem na vrch, vymazem, splaynem lavy subtree tak, aby najvacsi prvok z neho bol novy head a na pravu stranu k nemu pripojim pravy subtree
    if (!head) {//nemame head
        return NULL;
    }
    head = splay(head, input);//dostaneme prvok co chceme vymazat navrchol
    NODE *temp;
    if (((head->n_l) == NULL) && ((head->n_p) == NULL)) {//nas prvok je jediny v strome, vymazem ho
        free(head);
        return NULL;
    } else if (head->n_l==NULL){//ak ma iba pravý subtree, tak náš prvok vymažem a jeho child nastavím na head
        temp=head;
        head=head->n_p;
        free(temp);
        temp=NULL;
        return head;
    } else if(head->n_p==NULL){//ak ma iba lavy subtree, náš prvok vymažem a jeho child nastavím na head
        temp=head;
        head=head->n_l;
        free(temp);
        temp=NULL;
        return head;
    }
    else {//ak má 2 childov, tak si oboch uložím, najdem najväčší prvok z ľavého subtree a splaynem ho na miesto, kde som mal uložeńy lavy child
        NODE *lavyT = head->n_l;
        NODE *pravyT = head->n_p;
        int hladany = (biggestR(lavyT))->cislo;
        lavyT = splay(lavyT, hladany);
        lavyT->n_p = pravyT;//pripojím pravého childa k aktuálnemu ľavému childovi (najvacsi prvok z laveho subtree, ktory som splayol)
        free(head);
        head = NULL;
        return lavyT;

    }
}

int main() {
    NODE *head = NULL;
    int input = 0;
    char slovo[10];
    char value[INFO_V];
    FILE *f = NULL;
    FILE *v=NULL;
    v=fopen("vysledkytestov.txt","w");

    for (int i = 0; i < 7; i++) {
        if (i == 0) {
            f = fopen("TESTS10.txt", "r");
            fprintf(v,"Testujeme 10 prvkov v subore\n");
        }
        if (i == 1) {
            f = fopen("TESTS100.txt", "r");
            fprintf(v,"Testujeme 100 prvkov v subore\n");
        }
        if (i == 2) {
            f = fopen("TESTS1000.txt", "r");
            fprintf(v,"Testujeme 1000 prvkov v subore\n");
        }
        if (i == 3) {
            f = fopen("TESTS10000.txt", "r");
            fprintf(v,"Testujeme 10000 prvkov v subore\n");
        }
        if (i == 4) {
            f = fopen("TESTS100000.txt", "r");
            fprintf(v,"Testujeme 100000 prvkov v subore\n");
        }
        if (i == 5) {
            f = fopen("TESTS1000000.txt", "r");
            fprintf(v,"Testujeme 1000000 prvkov v subore\n");
        }
        if (i == 6) {
            f = fopen("TESTS10000000.txt", "r");
            fprintf(v,"Testujeme 10000000 prvkov v subore\n");
        }
        if (f == NULL) {
            fprintf(v,"Neotvoreny subor\n");
        } else {
            for (int j = 0; j < 3; j++) {
                clock_t start_time = clock();
                if (j == 0) {
                    fprintf(v,"Insert-Search\n");
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        head = insert(head, input,value);
                        head=splay(head,input);
                    }
                    rewind(f);
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        splay(head, input);
                    }
                    clock_t end_time = clock();
                    double duration = (double) (end_time - start_time) / CLOCKS_PER_SEC;
                    fprintf(v,"Dlzka programu bola: %f sekund\n", duration);
                    rewind(f);
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        head = delete(head, input);
                    }
                }
                if (j == 1) {
                    fprintf(v,"Insert-Delete\n");
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        head = insert(head, input, value);
                        head=splay(head,input);
                    }
                    rewind(f);
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        head = delete(head, input);
                    }
                    clock_t end_time = clock();
                    double duration = (double) (end_time - start_time) / CLOCKS_PER_SEC;
                    fprintf(v,"Dlzka programu bola: %f sekund\n", duration);
                }
                if (j == 2) {
                    fprintf(v,"Insert-Search-Delete\n");
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        head=insert(head,input,value);
                        head = splay(head, input);
                    }
                    rewind(f);
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        splay(head, input);
                    }
                    rewind(f);
                    while ((fgets(slovo, 10, f)) != NULL) {
                        input = atoi(slovo);
                        fgets(value, INFO_V, f);
                        head = delete(head, input);
                    }
                    clock_t end_time = clock();
                    double duration = (double) (end_time - start_time) / CLOCKS_PER_SEC;
                    fprintf(v,"Dlzka programu bola: %f sekund\n\n\n", duration);
                }
                rewind(f);
            }
            fclose(f);
        }
    }
    fclose(v);
    return 0;
}