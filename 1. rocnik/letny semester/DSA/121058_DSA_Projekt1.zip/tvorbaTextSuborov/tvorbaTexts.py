import random
import string

count=10
filename= 'TESTS'+str(count)+'.txt'
# Generate 1000 random numbers between 0 and 9999
numbers = [random.randint(0, 9999) for _ in range(10)]

# Generate 1000 random words of length 10
words = [''.join(random.choice(string.ascii_lowercase) for _ in range(10)) for _ in range(10)]

# Combine the numbers and words into pairs
pairs = [(numbers[i], words[i]) for i in range(10)]

# Write the pairs to a file
with open(filename, 'w') as f:
    for pair in pairs:
        f.write(str(pair[0]) + '\n' + pair[1] + '\n')