#include <stdio.h>
#include <stdlib.h>

int main(){
    int pocet;
    scanf("%d",&pocet);
    char *pole= (char*) malloc(pocet*sizeof (char));

    for (int i=0;i<(pocet+1);i++){
        scanf("%c",pole+i);
    }
    for (int i=0;i<pocet;i++){
        printf("%c",*(pole-i+pocet));
    }
    return 0;
}