#include <stdio.h>
#include <stdlib.h>




void alokuj_2D_Pole(char ***pole, int *total) {
    *pole = (char **) malloc(*total * sizeof(char *));
    for (int i = 0; i < *total; i++) {
        (*pole)[i] = (char *) malloc(12 * sizeof(char));
        scanf("%s", (*pole)[i]);
    }


}
void vypis_1D_Pole(int *total, char ***pole) {
    for (int i = 0; i < *total; i++) {
        printf("%s,", (*pole)[i]);
    }
}

void maximum_poz(int *total,char ***pole,char **maximum){
    int max=-99;
    for (int i = 0; i < *total; i++){
        int cislo=atoi((*pole)[i]);
        if(cislo>max) {
            max=cislo;
            *maximum=(*pole)[i];
        }
    }
}

void minimum_poz(int *total,char ***pole,char **minimum){
    int min=99;
    for (int i = 0; i < *total; i++){
        int cislo=atoi((*pole)[i]);
        if(cislo<min) {
            min=cislo;
            *minimum=(*pole)[i];
        }
    }
}

int main() {
    char **pole;
    int total = 0;
    char *maximum,*minimum;
    printf("rozmer pola");
    scanf("%d", &total);
    alokuj_2D_Pole(&pole, &total);
    vypis_1D_Pole(&total,&pole);
    maximum_poz(&total,&pole,&maximum);
    printf("\nMaximalna hodnota je %s",maximum);
    minimum_poz(&total,&pole,&minimum);
    printf("\nMinimalna hodnota je %s",minimum);


    return 0;
}
