#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const int N=20;

int magicky(int pole[N][N], int *rozmer){
    int sucet=0,sucetu=0,pravdivost=1,sucetu2=0;

    for (int i = 0; i < *rozmer; i++) {
        int sucetr=0,sucets=0;
        for (int k = 0; k < *rozmer; k++) {
            sucetr+=pole[i][k];
            sucets+=pole[k][i];
            if(k==0) sucetu+=pole[i][i];
            if(k==0) sucetu2+=pole[*rozmer-i-1][*rozmer-i-1];
        }
        if(i==0) sucet=sucetr;
        if(sucetr!=sucet) pravdivost=0;
        if(sucets!=sucet) pravdivost=0;
    }
        if(sucetu2!=sucet) pravdivost=0;
    if(sucetu!=sucet) pravdivost=0;
    if(pravdivost==1) printf("je magicky");
    else printf("neni magicky");
}


int main() {
    int rozmer;
    int pole[N][N];
    printf("zadaj rozmer stvorca");
    scanf("%d", &rozmer);
    printf("zadaj %d cisiel",(rozmer*rozmer));
    if (rozmer > N) {
        printf("Chyba");
    } else {
        for (int i = 0; i < rozmer; i++) {
            for (int k = 0; k < rozmer; k++) {
                scanf("%d", &pole[i][k]);
            }
        }
        magicky(&pole,&rozmer);
    }
            return 0;
}