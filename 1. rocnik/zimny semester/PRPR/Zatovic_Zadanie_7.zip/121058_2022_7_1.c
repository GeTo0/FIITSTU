#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>



void alokuj_2D_pole(int m, int n, int ***pole) {
    *pole = (int **) malloc((m) * sizeof(int *));
    for (int i = 0; i < ((m)); i++) {
        (*pole)[i] = (int *) malloc((n) * sizeof(int));
        for (int k = 0; k < (n); k++) {
            int c = 0;
            scanf("%d", &c);
            (*pole)[i][k] = c;
        }
    }
}

void vypis_2D_pole(int m, int n, int ***pole) {
    for (int i = 0; i < ((m)); i++) {
        for (int k = 0; k < (n); k++) {
            printf("%d", (*pole)[i][k]);
        }
        printf("\n");
    }
}

void uvolni(int m, int n, int ***pole) {
    for (int i = 0; i < m; i++) free((*pole)[i]);
    free(*pole);
}

int main() {
    int m, n;                    /*m = pocet riadkov, n=stlpov*/
    printf("napis rozmery pola");
    scanf("%d", &n);
    scanf("%d", &m);
    int **pole;
    alokuj_2D_pole(m, n, &pole);
    vypis_2D_pole(m, n, &pole);
    uvolni(m, n, &pole);
    return 0;
}
