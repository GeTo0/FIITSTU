#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    FILE *f = NULL;
    char znak;
    int riadok=1;
    int pole[26];
    memset(pole,0,26*sizeof(int));
    f = fopen(argv[1], "r");

    for(int i=65;i<91;i++){                 /* vyprintovanie "r" pre oznacenie riadku a vypisanie celej abecedy*/
        if(i==65) printf("r ");
        printf("%c ",i);
    }
    printf("\n");
    while((znak=fgetc(f))!=EOF){
                if ((64 < znak) && (znak < 91)) {
                    pole[znak - 65]++;
                }
                if ((96 < znak) && (znak < 123)) {
                    pole[znak - 97]++;
                }
                if (znak == '\n') {
                    for (int j = 0; j <26; j++) {          /*printovanie cisla riadku a nasledne pola ktore obsahuju pocty hodnot nazbieranych vyssie*/
                        if (j == 0) {
                            printf("%d ", riadok);
                            riadok++;
                        }
                        printf("%d ", pole[j]);
                    }
                    printf("\n");
                    memset(pole, 0, 26*sizeof(int));  /*vyresetovanie pola aby smem ohli pocitat s pismenami iba v dalsiom riadku*/
                }

    }
    return 0;
}
