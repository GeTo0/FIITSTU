#include <stdio.h>

int main()
{
    char veta[]= "\t \\*/ Toto je /\"backslash/\": '\'\\*/ \n";
    printf("%s",veta);
    return 0;
}