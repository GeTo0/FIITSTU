#include <stdio.h>

int main()
{
    float num1,num2;
    scanf("%f",&num1,1);
    num2=num1*0.8;
    printf("Cena bez dane je %0.1f\nPredajna cena s danou 20%: %0.1f",num1,num2);
    return 0;
}