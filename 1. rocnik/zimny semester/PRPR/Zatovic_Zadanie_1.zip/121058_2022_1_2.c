#include <stdio.h>
int main()
{
    int c;
    c = getchar();
    putchar(c);
    putchar('\n');
    return 0;
}