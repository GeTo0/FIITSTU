#include <stdio.h>

int main()
{
    int num1,mocnina;
    scanf("%d",&num1,1);
    mocnina=num1*num1;
    printf("druha mocnina je %d",mocnina);
    return 0;
}