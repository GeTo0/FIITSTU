#include <stdio.h>

int main()
{
    int num1,num2;
    scanf("%d %d", &num1,&num2,1,1);
    int sucet,sucin;
    sucet=num1+num2;
    sucin=num1*num2;

    printf("sucet je %d\nsucin je %d",sucet,sucin);
    return 0;
}
