#include <stdio.h>

int main()
{
    float num1,num2,num3,objem;
    scanf("%f %f %f",&num1,&num2,&num3,1,1,1);
    objem=num1*num2*num3;
    printf("Cena bez dane je %0.2f",objem);
    return 0;
}