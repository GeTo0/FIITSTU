#include <stdio.h>

int main()
{
    float num1,pi,polomer;
    scanf("%f",&num1,1);
    pi=3.14;
    polomer=2*pi*num1;
    printf("polomer kruhu je %0.2f",polomer);
    return 0;
}