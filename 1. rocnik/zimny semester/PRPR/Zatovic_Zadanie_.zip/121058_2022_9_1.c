#include <stdio.h>
#include <string.h>

int main() {
    char meno[15];
    char pmien[100][15];
    int pocet[100], counter=0;
    memset(pocet,0,100*sizeof(int));

    while (scanf("%s",meno) != EOF){      /* treba cez terminal robit, skonci pri ctrl Z*/
        int pravdivost=1;
        for(int i=0;i<counter;i++){
            if((strncmp(meno,pmien[i],15))==0){
                pravdivost=0;
                pocet[i]++;
            }
        }
        if(pravdivost==1){
            strncpy(pmien[counter],meno,15);
            pocet[counter]++;
            counter++;
        }
    }
    int maximum=-999;
    char najc[15];
    for(int i=0;i<counter;i++){
        if(pocet[i]>maximum) {
            maximum=pocet[i];
            strncpy(najc,pmien[i],15);
        }
    }
    printf("Najcastejsie bol v kine %s a to prave %d krat",najc,maximum);

return 0;
}
