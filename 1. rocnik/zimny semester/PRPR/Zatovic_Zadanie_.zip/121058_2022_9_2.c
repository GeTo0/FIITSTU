#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*printf("Ak chcete pridat tovar, napiste 'pridat'\n");
    scanf("%s",input);
    if(strncmp(input,"pridat",8)==0){
    printf("cau");
    }*/

typedef struct {
    char *tovar;
    char *vyrobca;
    int kusy;
    float cena;
} POTRAVINA;

void vypis(int *dlzka, POTRAVINA **potraviny) {
    for (int i = 0; i < *dlzka; i++) {
        printf("%s\t", (*potraviny)[i].tovar);
        printf("%s\t", (*potraviny)[i].vyrobca);
        printf("%d\t", (*potraviny)[i].kusy);
        printf("%0.2f\n", (*potraviny)[i].cena);
    }
}

int main() {
    int dlzka = 0, pravdivost = 1, inputI = 0, otazka;
    char input[20], coteraz[3], znak;
    float inputF = 0;

    POTRAVINA *potraviny;
    potraviny = malloc(sizeof(POTRAVINA) * dlzka);

    while ((scanf("%s", znak) != EOF)) {
        if (pravdivost == 0) {
            printf("Ak chcete zadat dalsi tovar, napiste 1");
            if(scanf("%d",otazka)==1) pravdivost=1;
        }
        while (pravdivost == 1) {
            printf("\n");
            potraviny = realloc(potraviny, sizeof(POTRAVINA) * (dlzka + 1));
            printf("Nazov potraviny:\n");
            scanf("%s", input);
            potraviny[dlzka].tovar = malloc(20 * sizeof(char));
            strcpy(potraviny[dlzka].tovar, input);

            printf("Nazov vyrobcu:\n");
            scanf("%s", input);
            potraviny[dlzka].vyrobca = malloc(20 * sizeof(char));
            strcpy(potraviny[dlzka].vyrobca, input);

            printf("Pocet kusov:\n");
            scanf("%d", &inputI);
            potraviny[dlzka].kusy = malloc(sizeof(int));
            potraviny[dlzka].kusy = inputI;

            printf("Cena:\n");
            scanf("%f", &inputF);
            potraviny[dlzka].cena = inputF;

            dlzka++;

            printf("Ak chcete dalej nacitavat tovar, napiste 1\n");
            printf("Ak uz nechcete nacitat dalsi tovar, napiste 0\n");
            scanf("%s", coteraz);

            if (strncmp(coteraz, "0", 1) == 0) {
                pravdivost = 0;
            }
        }

        vypis(&dlzka, &potraviny);
    }
    free(potraviny);
    return 0;
}