#include <stdio.h>

int main() {
    int i, N;
    float c1,predosle;
    int spravnost;
    printf("Nacitaj N:");
    scanf("%d", &N);
    printf("Zadaj N cisiel:");


    for (i = 0; i < N; i++) {
        scanf("%f", &c1);
        if (i == 0)
            if ((c1 < 0) || (c1 > 10)) {
                spravnost=0;
            }
            else    {
                predosle=c1;
            }

        else{
            if (((c1) < (2*(predosle))) && (c1 > (0.5*predosle))){
                }
            else {
                spravnost=0;
            }}
        predosle=c1;
    }
    if (spravnost==0)
        printf("Postupnost je zla");
    else
        printf("Postupnost je dobra");
    return 0;
}