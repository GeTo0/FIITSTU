#include <stdio.h>
#include <conio.h>

int main() {
    char poleA[15];
    char poleB[15];
    int i,j=14;

    printf("Napis 15 roznych znakov");
    for (i=0;i<15;i++) {
        scanf("%s", &poleA[i]);
        poleB[j] = poleA[i];
        j--;
    }

    for (i=0; i<15;i++){
        printf("%c",poleB[i]);
    }
    return 0;
}