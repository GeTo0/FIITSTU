#include <stdio.h>
#include <conio.h>

int main() {
    int poleA[7],i;
    int poleB;
    printf("Napis 7 roznych cisiel od 1 po 9");
    for (i=0;i<7;i++)                                       /*Nacitanie pola A*/
        scanf("%d",&poleA[i]);

    printf("x= {");
    for (i=0; i<7;i++){                                     /*Vypisanie pola A*/
        printf("%d ",poleA[i]);
    }
    printf("} \n");
    printf("y:{ ");
    for (i=0; i<7;i++){                                     /*Vypisanie pola B*/
        if(poleA[i]%2==0){
            printf("%d ",poleA[i]);
        }}
    printf("}");


    return 0;
}