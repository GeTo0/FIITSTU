#include <stdio.h>

int main() {
    int i,j,x;
    printf("Napis neparne cislo z intervalu 1 az 15:");
    scanf("%d", &x);

    if ((x<1) || (x>15) || (x%2==0)) {
        printf("Cislo nie je z daneho intervalu alebo je parne");

    }
    else{
        for (i = 0; i < x; i++) {
            for (j=0;j<x;j++) {
                if ((i==j) || (j==(x-+1-i)) || (j==((x-1)/2)) || i==((x-1)/2)){
                    printf("*");
                }
                else {
                    printf(" ");
                }

            }
            printf(" \n");
        }
    }
    return 0;
}