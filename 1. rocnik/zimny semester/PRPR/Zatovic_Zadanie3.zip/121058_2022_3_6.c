#include <stdio.h>
#include <stdlib.h>
int main() {
    int f,g,i,aktualne;
    printf("zadaj 2 cisla \n");
    scanf("%d %d", &f,&g);
    if (f<g){
        aktualne=f;
        for (i=0;i<(abs(f-g)+1);i++) {
            if (aktualne%3==0)
                printf("%d ",aktualne);
            aktualne+=1;
    }
    }
    else
        printf("Neplatny vstup");
    return 0;
}