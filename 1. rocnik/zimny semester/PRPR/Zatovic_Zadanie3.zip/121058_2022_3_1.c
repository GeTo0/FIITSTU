#include <stdio.h>

int main()
{
    float c1,c2,spolu;
    char znak;

    scanf("%f %f %c",&c1,&c2,&znak,"\n");

    switch(znak)
    {
        case '+' :
            spolu=c1+c2;
            printf("%g %c %g = %g", c1,znak, c2, spolu);break;
        case '-' :
            spolu=c1-c2;
            printf("%g %c %g = %g", c1,znak, c2, spolu);break;
        case '*' :
            spolu=c1*c2;
            printf("%g %c %g = %g", c1,znak, c2, spolu);break;
        case '/' :
            spolu=c1/c2;
            printf("%g %c %g = %g", c1,znak, c2, spolu);break;
        default:
            printf("Zle zadana volba ");
    }

    return 0;
}