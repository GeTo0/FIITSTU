#include <stdio.h>

int main() {
    float x,j;
    int i,vysledok,k;
    printf("Nacitaj cele nezaporne cislo");
    scanf("%f",&x);
    i=(int)x;
    j=(float)x;

    while ((x<0) || (i-j)!=0){
        printf("Nacitaj nezaporne cele cislo");
        scanf("%f",&x);
        i=(int)x;
        j=(float)x;
    }
    vysledok=i;

    for (k=(i-1);(k)>0;k--){
        vysledok*=(k);
    }
    printf("vysledkok je %d",vysledok);
    return 0;
}