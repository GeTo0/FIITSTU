#include <stdio.h>

int main() {
    int  i, N;
    float c1,min,max;
    printf("Nacitaj N:");
    scanf("%d", &N);
    printf("Zadaj N cisiel:");

    min=100000;
    max=-1000000;

    for (i = 0; i < N; i++){
        scanf("%f",&c1);
        if (c1<min){
            min=c1;
        }

        else if (c1>max){
            max=c1;
        }

    }
    printf("min %g \n",min);
    printf("max %g",max);
    return 0;
    }