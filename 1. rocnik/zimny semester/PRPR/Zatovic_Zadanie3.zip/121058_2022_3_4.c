#include <stdio.h>

int main() {
    int i, N,c,pocet;
    printf("Napis kolko N cisiel chces nacitat:");
    scanf("%d", &N);
    printf("Zadaj cisla:");


    for (i = 0; i < N; i++) {
        scanf("%d", &c);
        if ((c>0)&&(c<101))
            pocet+=1;
    }
    printf("%d",pocet);

    return 0;
}