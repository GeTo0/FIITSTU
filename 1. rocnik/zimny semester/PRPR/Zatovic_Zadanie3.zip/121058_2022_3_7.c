#include <stdio.h>

int main() {
    int j,i,x, teraz;
    printf("Napis cislo z intervalu 1 az 15:");
    scanf("%d", &x);

    if ((x<1) || (x>15)) {
        printf("Cislo nie je z daneho intervalu");

    }
    else{
        for (i = 1; i < (x+1); i++) {
            printf("%d: ",i);
            for (j=(x+1-i);j>0;j--) {
                printf("%d ", j);
            }
            printf(" \n");

            }
    }

    return 0;
}