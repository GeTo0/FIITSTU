#include <stdio.h>
int main() {
    char znakP, znakD;
    int rozdielne_znaky=0, navyse_znaky=0;
    FILE* prvy;
    FILE* druhy;
    prvy=fopen("prvy.txt", "r");
    druhy=fopen("druhy.txt","r");
    while ((znakP=fgetc(prvy))!=EOF && (znakD=fgetc(druhy))!=EOF){
        if (znakP!=znakD){
            rozdielne_znaky+=1;
        }
    }
    while((znakD=fgetc(druhy))!=EOF || (znakP=fgetc(prvy))!=EOF){
        navyse_znaky+=1;
    }
    printf("Pocet roznych znakov: %d\n", rozdielne_znaky);
    printf("Jeden zo suborov je dlhsi o: %d znaky\n",navyse_znaky);
}