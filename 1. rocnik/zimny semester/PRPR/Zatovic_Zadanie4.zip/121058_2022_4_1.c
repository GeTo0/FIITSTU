#include <stdio.h>


int zisti_prvocislo(int cislo){
    for(int i=2;(i*i)<=cislo;i++){
        if (cislo%i==0)
            return -1;
    }
return 1;
}

int main() {
    int a,b;
    scanf("%d %d",&a,&b);
    for (int cislo=a;cislo<=b;cislo++){
        zisti_prvocislo(cislo);
        if (zisti_prvocislo(cislo)==1){
            printf("%d ",cislo);
        }
    }
    return 0;
}