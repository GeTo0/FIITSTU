#include <stdio.h>
int sucet(int n) {
    if (n < 1) return 0;
    return (n % 10) + sucet(n / 10);
}

int main(){
    int n;
    scanf("%d",&n);

    printf("%d \n",sucet(n));

    return 0;
}
