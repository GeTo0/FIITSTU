#include <stdio.h>

long reverzne_cislo(long x) {
    int r,sum=0,zaklad;
    zaklad=x;
    while(x>0) {
        r = x % 10;             /* r je zvysok ktory dostaneme po vydeleni cisla X desiatimi*/
        sum = (sum * 10) + r;   /* zvysok sa zapise do sumaru a v nasledovnych krokoch sa bude nasobit desiatimi, co zaisti prepisanie cisla odzadu*/
        x=x/10;                 /* cislo vydelime 10timi aby sme mohli prejst na dalsiu cislicu*/
                                /* cislo 12321 vydelime 10timi, zvysok je 1, ten sa zapise do sumu (=1), 12321 sa vydeli 10 = 1232. Nasledovny ciklus
                                 * sa 1232 vydeli 10timi a zostane zvysok 2, predosly sum(=1) sa vynasobi 10 timi a pripocita sa 2ka a sum(=12) a toto sa opakuje
                                 * az po posledne cislo, kde sa sum nazbiera do cisla 12321 a to sa porovna so zaciatocnim cislom x*/
    }
        if(zaklad==sum){
            printf("je palindrom\n");
        }
        else{
            printf("nie je palindrom\n");
        }
}
int main() {
    long x;
    while((scanf("%d",&x))!=EOF){
        reverzne_cislo(x);
}
        return 0;
}
