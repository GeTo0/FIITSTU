#include <stdio.h>
#include <conio.h>

int main() {
    FILE *fp;
    char data;
    int medzery;

    fp = fopen("text.txt", "r");
    if (fp != NULL) {
        while((data= fgetc(fp))!=EOF) {
            if (data=='x' || data=='X'){
                printf("Precital som X\n");
            }
            if (data=='y' || data=='Y'){
                printf("Precital som Y\n");
            }
            if (data=='$' || data=='#' || data=='&'){
                printf("Precital som riadiaci znak\n");
            }
            if (data==' '){
                medzery++;
            }
            if (data=='*'){
                printf("Koniec");
                break;
            }}}
    else{
        printf("Neexistuje subor: text.txt");
    }
    fclose(fp);
    return 0;
}