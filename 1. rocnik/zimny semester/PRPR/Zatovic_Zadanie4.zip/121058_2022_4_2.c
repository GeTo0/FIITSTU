#include <stdio.h>


double tyzdenna_mzda(double h_mzda, double hod){
    double spolu=h_mzda*hod;
    printf("Hod. mzda %0.2lf Euro/hod, hodin: %g, spolu: %0.2lf \n",h_mzda,hod,spolu);
}

int main() {
    int vstupy;
    double h_mzda,hod;
    printf("Pocet vstupov");
    scanf("%d",&vstupy);

    for (int i=0;i<vstupy;i++){
        scanf("%lf %lf",&h_mzda,&hod);
        tyzdenna_mzda(h_mzda,hod);
        }
    return 0;
}