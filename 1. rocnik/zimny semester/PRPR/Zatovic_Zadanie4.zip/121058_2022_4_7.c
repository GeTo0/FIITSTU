#include <stdio.h>
#include <conio.h>




int main() {

    FILE *fp;
    char data;
    int i;
    int sucet = 0;
    int cislo;

    fp = fopen("cisla.txt", "r");
    if (fp != NULL) {
        while((data= getc(fp))!=EOF) {
            ungetc(data,fp);
            fscanf(fp, "%d", &cislo);
            printf("%d\n",cislo);
            sucet += cislo;
        }
        printf("Sucet cisiel je %d", sucet);
    }
    else{
        printf("Neexistuje subor: cisla.txt");
    }

    fclose(fp);
    getch();
    return 0;
}