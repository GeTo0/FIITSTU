#include <stdio.h>

int main() {
    float x,vypocet;
    printf("napis cislo");
    scanf("%f",&x);
    FILE *f;
    f = fopen("nasobky.txt", "wt");
    for(float i=1;i<11;i++) {
        vypocet = (x * i);
        fprintf(f, "%g * %0.2f = %0.2f\n",i,x,vypocet);
    }
    fclose(f);
    return 0;
}