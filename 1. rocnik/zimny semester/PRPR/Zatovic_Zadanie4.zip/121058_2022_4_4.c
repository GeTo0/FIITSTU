#include <stdio.h>

int sucet(int n) {
    if(n<1) return 0;
    if (n%2==0){
        n--;;
        };
    return (n) + sucet((n - 2));
}

int main(){
    int n;
    scanf("%d",&n);
    sucet(n);
    printf("%d \n",sucet(n));

    return 0;
}