#include <stdio.h>
int main() {
    FILE* znak;
    znak = fopen("znak.txt", "r");
    char x;
    scanf("%c",&x);
    if (x=='s'){
        FILE* novy;
        novy = fopen("novy.txt", "w");
        char znak;
        while (fscanf(znak,"%c",&znak)!=EOF){
            fprintf(novy,"%c",znak);
        }
        fclose(novy);
    }
    else{
        char znakP;
        while(fscanf(znak,"%c",&znakP)!=EOF){
            printf("%c",znakP);
        }
    }
    fclose(znak);
    return 0;
}