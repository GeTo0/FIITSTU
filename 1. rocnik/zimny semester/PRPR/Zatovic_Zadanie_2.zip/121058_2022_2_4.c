#include <stdio.h>


int main()
{
    char p1,medzera,p2;
    char prve,druhe;
    scanf("%c %c",&p1,&p2);
    printf("vyber %d vyber2 %d \n",p1,p2);

    if(p1>=97&&p1<=122)
        prve=(int)p1-('a'-'A');
    else if (p1>=65&&p1<=90)
        prve=(int)p1+('a'-'A');
    if(p2>=97&&p2<=122)
        druhe=(int)p2-('a'-'A');
    else if (p2>=65&&p1<=90)
        druhe=(int)p2+('a'-'A');


    printf("%c %d \n",prve,prve);
    printf("%c %d \n",druhe,druhe);

    return 0;
}