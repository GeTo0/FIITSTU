#include <stdio.h>

int main()
{
    float cislo;
    scanf("%f",&cislo);
    int x=(int)cislo;
    cislo=cislo+0.5;
    int y=(int)cislo;
    printf("%d %d",x, y);
    return 0;
}