#include <stdio.h>

int main()
{
    int c1,c2,spolu;
    char znak;

    scanf("%d %d %c",&c1,&c2,&znak);

    switch(znak)
    {
        case '+' :
            spolu=c1+c2; break;
        case '-' :
            spolu=c1-c2; break;
        case '*' :
            spolu=c1*c2; break;
        case '/' :
            spolu=c1/c2; break;
    }
    printf("%d %c %d = %d", c1,znak, c2, spolu);

    return 0;
}