#include <stdio.h>

int main()
{
    float hmotnost,vyska,BMI;
    scanf("%f %f",&hmotnost,&vyska);
    BMI=hmotnost/((vyska/100)*(vyska/100));
    printf("tvoje BMI je %f",BMI);
    return 0;
}