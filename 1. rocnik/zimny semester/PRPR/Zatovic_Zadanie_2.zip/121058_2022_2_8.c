#include <stdio.h>


int main()
{
    int a,b,c,d,e,vysledok1,vysledok2;
    scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);
    {
        vysledok1 = e / --a * b++ / c++;
    }
    scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);
    {
        vysledok2 = a %= b = d = 1 + e / 2;     /* Operácia "+" ma prednost pred =, tym padom sa najprv spravi e/2, k tomu sa pripočíta 1 a keďže sa ide sprava dolava, tak d=1+e/2, potom b=d a a%=b */
    }
    printf("%d \n%d",vysledok1,vysledok2);
    return 0;
}