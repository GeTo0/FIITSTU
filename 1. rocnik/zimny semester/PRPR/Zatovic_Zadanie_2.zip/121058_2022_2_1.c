#include <stdio.h>

int main()
{
    float num1, num2, num3, priemer;
    scanf("%f %f %f", &num1, &num2, &num3);
    priemer = (num1 + num2 + num3) / 3;
    printf("Aritmeticky priemer je %1.3f", priemer);
    return 0;
}