#include <stdio.h>


int main()
{
    char p1,medzera,p2;
    char prve,druhe;
    scanf("%c",&p1);
    scanf("%c",&medzera);
    scanf("%c",&p2);

    prve=p1+32;
    druhe=p2+32;

    printf("%c ",druhe);
    printf("%c ",prve);

    return 0;
}