#include <stdio.h>


int main()
{
    int c1,c2;
    scanf("%d %d",&c1,&c2);

    if(c1>c2)
        printf("Cislo C1=%d je vacsie ako cislo C2=%d ",c1,c2);
    else if (c1==c2)
        printf("Cislo C1=%d je rovnako velke ako cislo C2=%d ",c1,c2);
    else if (c1<c2)
        printf("Cislo C1=%d je mensie ako cislo C2=%d ",c1,c2);

    return 0;
}