#include <stdio.h>

int maximum(int *pn,int *pd){
    if (*pn>*pd){
        return (*pn);
    }
    else{
        return(*pd);
}}


int main(){
    int n,d;
    scanf("%d %d",&n,&d);
    int *pn=&n,*pd=&d;
    maximum(&n,&d);
    printf("Cislo %d je vacsie",maximum(&n,&d));
    return 0;
}