#include <stdio.h>

void vymen_ukazovatele(int **a,int **b){
    int *temp = *a;
    *a = *b;
    *b = temp;
}


int main() {
    int a=10,b=14,*pa=&a,*pb=&b;
    printf("p_a %p \np_b %p\n",pa,pb);
    vymen_ukazovatele(&pa,&pb);
    printf("p_a %p \np_b %p",pa,pb);

    return 0;
}