#include <stdio.h>
#include <math.h>
int kvadraticka_rovnica(float a, float b, float c, float *k1, float *k2){
    float dis;
    dis=((b*b)-(4*a*c));
    if ((dis>0)&&(a!=0)) {
        printf("Pocet korenov kvadratickej rovnice je 2\n");
        *k1 = (-b + sqrt(dis)) / (2 * a);
        *k2 = (-b - sqrt(dis)) / (2 * a);
    }
    else if ((dis==0)&&(a!=0)){
        printf("Pocet korenov kvadratickej rovnice je 1\n");
        *k1 = (-b/(2 * a));
    }
    else if (a==0){
        printf("Pocet korenov kvadratickej rovnice je 1\n");
        *k1 = (-b/c);
    }
    else if ((dis<0)){
        printf("Pocet korenov kvadratickej rovnice je 0\n");
    }
    return 0;
}


int main() {
    float a,b,c,k1,k2;
    scanf("%f %f %f",&a,&b,&c);
    kvadraticka_rovnica(a,b,c,&k1,&k2);
    printf("%0.3f \n%.3f",k1,k2);
    return 0;
}
