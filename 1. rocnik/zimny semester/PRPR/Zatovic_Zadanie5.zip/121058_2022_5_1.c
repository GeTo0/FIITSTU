#include <stdio.h>

void nacitaj(float *n,float *d){
    *n=0;
    *d=0;
    scanf("%f",&*n);
    scanf("%f",&*d);
}

int vypocitaj(float n, float d, float *obsah, float *obvod){
    *obsah=(n*d);
    *obvod=(2*n+2*d);
    printf("obvod %0.3f \nobsah %0.3f",*obsah,*obvod);
    return 0;
}

int main() {
    float n,d,obsah,obvod;
    nacitaj(&n,&d);
    vypocitaj(n,d,&obsah,&obvod);

    return 0;
}
