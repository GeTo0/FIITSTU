#include <stdio.h>
#include <math.h>


int delitele(int x[], int pocetx, int y[], int k){
    int j=0,spolu,pocety;
    for(int i=0;i<10;i++){
        if (k % x[i] == 0){
            y[j] = x[i];
            j++;
            pocety++;
    }
    }
    return (pocety);
}


int main() {
    int k;
    scanf("%d",&k);
    int x[] = {4, 7, 10, 2, 3, 9, 6, 5, 8, 12};
    int pocetx=10;
    int y[10];
    int pocety = delitele(x,pocetx,y,k);
    printf("pocety=%d\n",pocety);

    for(int i=0;i<pocety;i++){
        printf("%d ", y[i]);
    }
    return 0;
}
