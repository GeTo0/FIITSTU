from fastapi import APIRouter

from dbs_assignment.endpoints import hello,status, infos

router = APIRouter()
router.include_router(hello.router, tags=["hello"])
router.include_router(status.router, tags=["status"])
router.include_router(infos.router, tags=["infos"])

