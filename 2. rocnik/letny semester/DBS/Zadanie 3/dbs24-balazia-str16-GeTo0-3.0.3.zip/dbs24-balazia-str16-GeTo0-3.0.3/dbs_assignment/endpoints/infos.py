from fastapi import APIRouter, FastAPI, HTTPException, Query
import psycopg2
import os
from dotenv import load_dotenv
from typing import List, Dict, Any

router = APIRouter()

def connect_to_postgres():
    try:
        # Connect to PostgreSQL database
        load_dotenv()
        db_name=os.getenv('DATABASE_NAME')
        db_user=os.getenv('DATABASE_USER')
        db_pass=os.getenv('DATABASE_PASSWORD')
        db_host=os.getenv('DATABASE_HOST')
        db_port=os.getenv('DATABASE_PORT')

        conn = psycopg2.connect(
            database=db_name,
            user=db_user,
            password=db_pass,
            host=db_host,
            port=db_port
        )
        return conn
    except psycopg2.Error as e:
        raise HTTPException(status_code=500, detail=str(e))



def get_post_comments(post_id):
    try:
        conn = connect_to_postgres()
        cur = conn.cursor()

        # Execute query to get users who commented on the specified post, sorted by creation time
        cur.execute("""
            SELECT users.id, users.reputation, users.creationdate, users.displayname, users.lastaccessdate,
                   users.websiteurl, users.location, users.aboutme, users.views, users.upvotes, users.downvotes,
                   users.profileimageurl, users.age, users.accountid
            FROM users
            JOIN comments ON users.id = comments.userid
            WHERE comments.postid = %s
            ORDER BY comments.creationdate DESC;
        """, (post_id,))
        users_data = cur.fetchall()

        # Close cursor and connection
        cur.close()
        conn.close()

        return users_data
    except psycopg2.Error as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/v2/posts/{post_id}/users")
async def get_post_users(post_id: int):
    users_data = get_post_comments(post_id)
    if not users_data:
        raise HTTPException(status_code=404, detail="No users found for the specified post.")
    else:
        formatted_users = [{
            "id": user[0],
            "reputation": user[1],
            "creationdate": user[2],
            "displayname": user[3],
            "lastaccessdate": user[4],
            "websiteurl": user[5],
            "location": user[6],
            "aboutme": user[7],
            "views": user[8],
            "upvotes": user[9],
            "downvotes": user[10],
            "profileimageurl": user[11],
            "age": user[12],
            "accountid": user[13]
        } for user in users_data]

        formatted_response = {"items": formatted_users}
        return formatted_response

@router.get("/v2/users/{user_id}/friends")
async def get_discussing_users(user_id: int):
    try:
        conn = connect_to_postgres()
        cur = conn.cursor()

        # Retrieve distinct users who commented on the specified user's posts or on posts the specified user commented on
        cur.execute("""
            SELECT DISTINCT u.id, u.reputation, u.creationdate, u.displayname, u.lastaccessdate,
                   u.websiteurl, u.location, u.aboutme, u.views, u.upvotes, u.downvotes,
                   u.profileimageurl, u.age, u.accountid
            FROM users u
            JOIN comments c ON u.id = c.userid
            JOIN posts p ON c.postid = p.id
            WHERE p.owneruserid = %s OR c.userid = %s
            ORDER BY u.creationdate;
        """, (user_id, user_id))

        discussing_users_data = cur.fetchall()

        cur.close()
        conn.close()
        formatted_users = [{
            "id": user[0],
            "reputation": user[1],
            "creationdate": user[2],
            "displayname": user[3],
            "lastaccessdate": user[4],
            "websiteurl": user[5],
            "location": user[6],
            "aboutme": user[7],
            "views": user[8],
            "upvotes": user[9],
            "downvotes": user[10],
            "profileimageurl": user[11],
            "age": user[12],
            "accountid": user[13]
        } for user in discussing_users_data]

        formatted_response = {"items": formatted_users}
        return formatted_response

    except psycopg2.Error as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/v2/tags/{tagname}/stats")
async def get_tag_stats(tagname: str):
    try:
        conn = connect_to_postgres()
        cur = conn.cursor()

        # SQL query to retrieve count of posts with the specified tag for each day of the week
        cur.execute("""
            SELECT EXTRACT(DOW FROM p.creationdate) AS day_of_week, COUNT(p.id)
            FROM posts p
            JOIN post_tags pt ON p.id = pt.post_id
            JOIN tags t ON pt.tag_id = t.id
            WHERE t.tagname = %s
            GROUP BY day_of_week
            ORDER BY day_of_week;
        """, (tagname,))
        tag_posts_count = cur.fetchall()

        # SQL query to retrieve total count of posts published on each day of the week
        cur.execute("""
            SELECT EXTRACT(DOW FROM creationdate) AS day_of_week, COUNT(id)
            FROM posts
            GROUP BY day_of_week
            ORDER BY day_of_week;
        """)
        total_posts_count = cur.fetchall()

        # Remap the days of the week to match your database's representation
        day_mapping = {
            1: "monday",
            2: "tuesday",
            3: "wednesday",
            4: "thursday",
            5: "friday",
            6: "saturday",
            0: "sunday"
        }

        tag_stats = {}
        for tag_count, total_count in zip(tag_posts_count, total_posts_count):
            day_of_week = int(tag_count[0])  # Extract day of the week
            tag_percentage = round(tag_count[1] / total_count[1] * 100, 2) if total_count[1] > 0 else 0
            tag_stats[day_mapping[day_of_week]] = tag_percentage

        cur.close()
        conn.close()

        return {"result": tag_stats}

    except psycopg2.Error as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/v2/posts/")
async def get_recent_posts(duration: int = Query(None), limit: int = Query(...), query: str = Query(None)):
    try:
        conn = connect_to_postgres()
        cur = conn.cursor()
        if duration:
        # SQL query to retrieve the `limit` newest resolved posts opened within the last `duration` minutes
            cur.execute("""
                SELECT id, creationdate, viewcount, lasteditdate, lastactivitydate, title, closeddate,
                ROUND(EXTRACT(EPOCH FROM (closeddate - creationdate)) / 60::numeric, 2) AS duration
                FROM posts
                WHERE closeddate IS NOT NULL
                AND EXTRACT(EPOCH FROM (closeddate - creationdate)) / 60 <= %s
                ORDER BY creationdate DESC
                LIMIT %s;
            """, (duration, limit))
            recent_posts = cur.fetchall()

            cur.close()
            conn.close()

            # Format the duration of opening for each post
            formatted_posts = []
            for post in recent_posts:
                post_id, creation_date, view_count, last_edit_date, last_activity_date, title, closed_date, duration_open = post
                formatted_post = {
                    "id": post_id,
                    "creationdate": creation_date.isoformat(),
                    "viewcount": view_count,
                    "lasteditdate": last_edit_date.isoformat() if last_edit_date else None,
                    "lastactivitydate": last_activity_date.isoformat() if last_activity_date else None,
                    "title": title,
                    "closeddate": closed_date.isoformat(),
                    "duration": duration_open
                }
                formatted_posts.append(formatted_post)

            formatted_response = {"items": formatted_posts}
            return formatted_response
        else:
            if query:
                # Search for posts containing the query string in title or body (case-insensitive)
                cur.execute("""
                    SELECT p.id, p.creationdate, p.viewcount, p.lasteditdate, p.lastactivitydate, p.title, p.body, p.answercount, p.closeddate, t.tagname
                    FROM posts p
                    JOIN post_tags pt ON p.id = pt.post_id
                    JOIN tags t ON pt.tag_id = t.id
                    WHERE LOWER(p.title) LIKE %s OR LOWER(p.body) LIKE %s
                    ORDER BY p.creationdate DESC
                    LIMIT %s;
                """, ('%' + query.lower() + '%', '%' + query.lower() + '%', limit))
            else:
                # Fetch posts without any query filter (LEFT join retrieves all even if null)
                cur.execute("""
                    SELECT p.id, p.creationdate, p.viewcount, p.lasteditdate, p.lastactivitydate, p.title, p.body, p.answercount, p.closeddate, t.tagname
                    FROM posts p
                    LEFT JOIN post_tags pt ON p.id = pt.post_id
                    LEFT JOIN tags t ON pt.tag_id = t.id
                    ORDER BY p.creationdate DESC
                    LIMIT %s;
                """, (limit,))

            posts_data = cur.fetchall()

            cur.close()
            conn.close()

            formatted_posts = []
            for post in posts_data:
                post_id, creation_date, view_count, last_edit_date, last_activity_date, title, body, answer_count, closed_date,tag_name = post
                formatted_post = {
                    "id": post_id,
                    "creationdate": creation_date.isoformat(),
                    "viewcount": view_count,
                    "lasteditdate": last_edit_date.isoformat() if last_edit_date else None,
                    "lastactivitydate": last_activity_date.isoformat() if last_activity_date else None,
                    "title": title,
                    "body": body,
                    "answercount": answer_count,
                    "closeddate": closed_date.isoformat() if closed_date else None,
                    "tags": tag_name
                }
                formatted_posts.append(formatted_post)

            return {"items": formatted_posts}

    except psycopg2.Error as e:
        raise HTTPException(status_code=500, detail=str(e))


#######################################################################################################################

@router.get("/v3/users/{user_id}/badge_history")
async def analyze_user_badges(user_id: str):
    try:
        conn = connect_to_postgres()
        cur = conn.cursor()

        query = """
            SELECT last_post_id_before_badge::numeric AS id,
               post_title::varchar AS title,
               post_created_at AT TIME ZONE 'UTC' AS created_at,
               position::numeric AS position,
               badge_id::numeric AS id,
               badge_type::varchar AS type,
               badge_created_at AT TIME ZONE 'UTC' AS created_at,
               position::numeric AS position
            FROM (
                SELECT *,
                       ROW_NUMBER() OVER(ORDER BY post_created_at) AS position
                FROM (
                    SELECT badge_posts.id AS badge_id,
                           badge_posts.date AS badge_created_at,
                           last_post_id_before_badge,
                           post_title,
                           badge_posts.name AS badge_type,
                           posts.creationdate AS post_created_at,
                           ROW_NUMBER() OVER(PARTITION BY last_post_id_before_badge ORDER BY badge_posts.date) AS badge_rank
                    FROM (
                        SELECT DISTINCT b.*,
                            (SELECT p.id
                             FROM posts p
                             WHERE p.owneruserid = b.userid
                             AND p.creationdate < b.date
                             ORDER BY p.creationdate DESC
                             LIMIT 1) AS last_post_id_before_badge,
                            (SELECT p.title
                             FROM posts p
                             WHERE p.owneruserid = b.userid
                             AND p.creationdate < b.date
                             ORDER BY p.creationdate DESC
                             LIMIT 1) AS post_title
                        FROM badges b
                        JOIN users u ON b.userid = u.id
                        WHERE u.id = %s
                    ) AS badge_posts
                    JOIN posts ON posts.id = last_post_id_before_badge
                    WHERE last_post_id_before_badge IS NOT NULL -- Filter out badges where there is no last post
                ) AS ranked_badges
                WHERE badge_rank = 1
            ) AS filtered_ranks;
        """
        cur.execute(query, (user_id,))
        badge_data = cur.fetchall()

        cur.close()
        conn.close()

        formatted_all = []
        for badge in badge_data:
            (last_post_id_before_badge, post_title, post_created_at, position,
             badge_id, badge_type, badge_created_at, _) = badge

            formatted_post = {
                "created_at": post_created_at.isoformat(),
                "id": last_post_id_before_badge,
                "position": position,
                "title": post_title,
                "type": 'post'
            }
            formatted_all.append(formatted_post)
            formatted_badge = {
                "created_at": badge_created_at.isoformat(),
                "id": badge_id,
                "position": position,
                "title": badge_type,
                "type": 'badge'
            }

            formatted_all.append(formatted_badge)

        final_format = {"items:": formatted_all}

        return final_format

    except psycopg2.Error as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/v3/tags/{tagname}/comments")
async def get_comments_by_tag(tagname: str, count: int):
    try:
        conn = connect_to_postgres()
        cur = conn.cursor()

        sql_query = """
            SELECT
                post_id::numeric AS post_id,
                post_title::varchar AS post_title,
                user_displayname::varchar AS user_displayname,
                comment_text::varchar AS comment_text,
                post_created_at AT TIME ZONE 'UTC' AS post_created_at,
                created_at AT TIME ZONE 'UTC' AS created_at,
                TO_CHAR(AGE(created_at AT TIME ZONE 'UTC', LAG(created_at AT TIME ZONE 'UTC', 1, post_created_at AT TIME ZONE 'UTC') OVER (PARTITION BY post_id ORDER BY created_at AT TIME ZONE 'UTC')), 'HH24:MI:SS') AS diff,
                TO_CHAR(INTERVAL '1 minute' * AVG(time_difference) OVER (PARTITION BY post_id ORDER BY created_at ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) / 60, 'HH24:MI:SS') AS avg
            FROM (
                SELECT
                    p.id AS post_id,
                    p.title AS post_title,
                    u.displayname AS user_displayname,
                    c.text AS comment_text,
                    p.creationdate AS post_created_at,
                    c.creationdate AS created_at,
                    EXTRACT(EPOCH FROM (c.creationdate - LAG(c.creationdate, 1, p.creationdate) OVER (PARTITION BY post_id ORDER BY c.creationdate))) AS time_difference

                FROM
                    posts p
                JOIN
                    post_tags pt ON p.id = pt.post_id
                JOIN
                    tags t ON pt.tag_id = t.id
                JOIN
                    comments c ON p.id = c.postid
                JOIN
                    users u ON c.userid = u.id
                WHERE
                    t.tagname = %s
                    AND p.id IN (
                        SELECT p.id
                        FROM posts p
                        JOIN comments c ON p.id = c.postid
                        GROUP BY p.id
                        HAVING COUNT(c.id) > %s
                        ORDER BY MIN(c.creationdate)
                    )
            ) AS Subquery
            ORDER BY
                created_at;
        """

        cur.execute(sql_query, (tagname, count))

        comments = []
        for row in cur.fetchall():
            post_id, post_title, user_displayname, comment_text, post_created_at, created_at, diff, avg = row
            comment_entry = {
                "post_id": post_id,
                "title": post_title,
                "displayname": user_displayname,
                "text": comment_text,
                "post_created_at": post_created_at.isoformat(),
                "created_at": created_at.isoformat(),
                "diff": diff,
                "avg": avg
            }
            comments.append(comment_entry)

        cur.close()
        conn.close()
        formatted_response= {"items": comments}
        return formatted_response

    except psycopg2.Error as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/v3/tags/{tagname}/comments/{position}")
async def get_comments_by_tag_and_position(tagname: str, position: int, limit: int):
    try:
        conn = connect_to_postgres()
        cur = conn.cursor()

        sql_query = """
            SELECT
                c.id AS comment_id,
                u.displayname AS displayname,
                p.body AS body,
                c.text AS text,
                c.score AS score
            FROM (
                SELECT
                    p.id AS post_id,
                    c.id AS comment_id,
                    c.text AS comment_text,
                    ROW_NUMBER() OVER (PARTITION BY p.id ORDER BY c.creationdate) AS comment_rank
                FROM
                    posts p
                JOIN
                    post_tags pt ON p.id = pt.post_id
                JOIN
                    tags t ON pt.tag_id = t.id
                JOIN
                    comments c ON p.id = c.postid
                JOIN
                    users u ON c.userid = u.id
                WHERE
                    t.tagname = %s
                ORDER BY
                    p.creationdate
            ) AS RankedPosts
            JOIN
                comments c ON RankedPosts.comment_id = c.id
            JOIN
                posts p ON RankedPosts.post_id = p.id
            JOIN
                users u ON c.userid = u.id
            WHERE
                comment_rank = %s
            LIMIT %s
        """

        cur.execute(sql_query, (tagname, position, limit))

        comments = []
        for row in cur.fetchall():
            comment_id, displayname, post_body, comment_text, score = row
            comment_entry = {
                "id": comment_id,
                "displayname": displayname,
                "body": post_body,
                "text": comment_text,
                "score": score,
                "position": position
            }
            comments.append(comment_entry)

        cur.close()
        conn.close()

        formatted_response = {"items": comments}
        return formatted_response

    except psycopg2.Error as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/v3/posts/{postid}")
async def get_post_thread(postid: int, limit: int):
    try:
        conn = connect_to_postgres()
        cur = conn.cursor()

        sql_query = """
            SELECT
                u.displayname,
                p.body,
                to_char(p.creationdate AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS created_at_utc
            FROM
                posts p
            JOIN
                users u ON p.owneruserid = u.id
            WHERE
                p.id = %s OR p.parentid = %s
            ORDER BY
                p.creationdate
            LIMIT %s;
        """

        cur.execute(sql_query, (postid, postid, limit))

        post_thread = []
        for row in cur.fetchall():
            displayname, body, created_at = row
            post_entry = {
                "displayname": displayname,
                "body": body,
                "created_at": created_at
            }
            post_thread.append(post_entry)

        cur.close()
        conn.close()

        formatted_response = {"items": post_thread}
        return formatted_response

    except psycopg2.Error as e:
        raise HTTPException(status_code=500, detail=str(e))
