from fastapi import APIRouter, FastAPI, HTTPException
import psycopg2
import os
from dotenv import load_dotenv

router = APIRouter()

@router.get("/v1/status")
async def postgres_version():
    try:
        # Connect to PostgreSQL database
        load_dotenv()
        db_name=os.getenv('DATABASE_NAME')
        db_user=os.getenv('DATABASE_USER')
        db_pass=os.getenv('DATABASE_PASSWORD')
        db_host=os.getenv('DATABASE_HOST')
        db_port=os.getenv('DATABASE_PORT')

        conn = psycopg2.connect(
            database=db_name,
            user=db_user,
            password=db_pass,
            host=db_host,
            port=db_port
        )
        # Create a cursor object
        cur = conn.cursor()

        # Execute query to get PostgreSQL version
        cur.execute("SELECT version();")
        version = cur.fetchone()[0]

        # Close cursor and connection
        cur.close()
        conn.close()

        return {'version': version}
    except psycopg2.Error as e:
        return {'error': str(e)}
