import psycopg2
import os
from dotenv import load_dotenv
from pydantic_settings import BaseSettings  # Import BaseSettings from pydantic_settings

# Load environment variables from .env file
load_dotenv()

connectiondic = {
    "NAME": os.getenv("DATABASE_USER")
}

# Access settings
print(connectiondic["NAME"])
