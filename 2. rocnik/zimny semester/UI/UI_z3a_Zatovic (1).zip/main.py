import math
import time
from tkinter import Tk
from tkinter import Canvas
import random


class DOT:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.distance = -1


def paint(data):
    window = Tk()
    window.geometry("1000x1000")
    window.configure(background="white")
    window.title("Canvas - Draw Shapes")
    window.resizable(False, False)
    canvas = Canvas(width=10000, height=10000, bg="white")
    canvas.pack(pady=20)

    for point in data:
        x = point.x
        y = point.y
        color = point.color
        canvas.create_oval((x + 5000 - 100) / 10, (y + 5000 - 100) / 10, (x + 5000 + 100) / 10, (y + 5000 + 100) / 10, fill=color)

    window.mainloop()


def classify(x, y, k, data):
    c_range = 50
    found_points = []
    while (len(found_points)) < k and c_range < 10000:
        for point in data:
            point.distance = math.sqrt((abs(point.x - x)) ** 2 + (abs(point.y - y)) ** 2)
            if point.distance <= c_range:
                if point not in found_points:
                    found_points.append(point)
        c_range += 50

    if len(found_points) >= k:
        sorted_data = sorted(found_points, key=lambda z: z.distance)

        r_count = sum(1 for point in sorted_data[:k] if point.color == "red") #gpt
        g_count = sum(1 for point in sorted_data[:k] if point.color == "green")
        b_count = sum(1 for point in sorted_data[:k] if point.color == "blue")
        p_count = sum(1 for point in sorted_data[:k] if point.color == "purple")

        color_counts = {"red": r_count, "green": g_count, "blue": b_count, "purple": p_count}
        max_color = max(color_counts, key=color_counts.get)

        data.append(DOT(x, y, max_color))
        return max_color


def main():
    start=time.time()
    class_R = [
        [-4500, -4400],
        [-4100, -3000],
        [-1800, -2400],
        [-2500, -3400],
        [-2000, -1400]
    ]
    class_G = [
        [+4500, -4400],
        [+4100, -3000],
        [+1800, -2400],
        [+2500, -3400],
        [+2000, -1400]
    ]
    class_B = [
        [-4500, +4400],
        [-4100, +3000],
        [-1800, +2400],
        [-2500, +3400],
        [-2000, +1400]
    ]
    class_P = [
        [+4500, +4400],
        [+4100, +3000],
        [+1800, +2400],
        [+2500, +3400],
        [+2000, +1400]
    ]

    data = []
    for i in range(5):  # append first 20 dots to data
        data.append(DOT(class_R[i][0], class_R[i][1], "red"))
        data.append(DOT(class_G[i][0], class_G[i][1], "green"))
        data.append(DOT(class_B[i][0], class_B[i][1], "blue"))
        data.append(DOT(class_P[i][0], class_P[i][1], "purple"))

    ranges = [
        ((-5000, 500), (-5000, 500)), #R
        ((-500, 5000), (-5000, 500)), #G
        ((-5000, 500), (-500, 5000)), #B
        ((-500, 5000), (-500, 5000))  #P
    ]
    decide = 0
    k = 7
    existing_coordinates=set()
    wrongcolors = 0

    for i in range(40000):
        what = random.randint(0, 100)
        x_range, y_range = ranges[decide]

        if what < 99:
            x = random.randint(*x_range)
            y = random.randint(*y_range)
            while (x, y) in existing_coordinates:  # Ensure unique coordinates
                x = random.randint(*x_range)
                y = random.randint(*y_range)
        else:
            x = random.randint(-5000, 5000)
            y = random.randint(-5000, 5000)
            while (x, y) in existing_coordinates:  # Ensure unique coordinates
                x = random.randint(-5000, 5000)
                y = random.randint(-5000, 5000)

        existing_coordinates.add((x, y))

        colornow=classify(x, y, k, data)

        if decide==0 and colornow != "red":
            wrongcolors+=1
        elif decide==1 and colornow != "green":
            wrongcolors+=1
        elif decide==2 and colornow != "blue":
            wrongcolors+=1
        elif decide==3 and colornow != "purple":
            wrongcolors+=1

        decide = (decide + 1) % 4
    print("There were total of "+str(wrongcolors)+" differently classified dots in my program")
    print("The percentage of my program is: "+str(100-((wrongcolors/40000)*100))+"%")
    end = time.time()
    print("Total time: "+str(end-start))


    paint(data)

if __name__ == "__main__":
    main()