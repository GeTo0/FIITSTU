import random
from operator import attrgetter
import tkinter as tk
import matplotlib.pyplot as plt

class Individual():
    def __init__(self, dna, path, treasures,
                 fitness):  # Class for each individual, containing their dna, path on map, fitness and number of treasures found
        self.dna = []
        self.dna.extend(dna)  # extends dna array with input of DNA
        self.path = path
        self.fitness = fitness
        self.treasures = treasures


def get_size():  # get size of map from text file
    file = open("size.txt", "r")
    size = int(file.readline())
    return size


def get_start_coordinates():  # returns starting position on map in type of array
    file = open("start.txt", "r")
    start = [0, 0]
    for line in file:
        start[0], start[1] = (int(line.split()[0]), int(line.split()[1]))
    return start


def get_treasure_coordinates(treasures):  # Function that fills treasures list with their coordinates
    file = open("treasure_coords.txt", "r")
    for line in file:
        temp = []
        temp.append(int(line.split()[0]))
        temp.append(int(line.split()[1]))
        treasures.append(temp)


def make_individual():  # creates random DNA for individual, length of 64 with integers from 0 to 255
    dna = []
    for i in range(64):
        dna.append(int(random.randint(0, 255)))
    return dna


def mutate(individual):  # 2.5% chance to mutate on each cell (changes its number on the index)
    for i in range(64):
        temp = random.randint(1, 1000)
        if temp <= 25:
            individual.dna[i] = random.randint(0, 255)


def get_path(dna_main):  # Turing machine to determing path of individual, no negative numbers allowed
    dna = dna_main.copy()
    index = 0
    moves = []
    for i in range(500):
        if dna[index] < 0:  # eliminate negative number
            dna[index] = 0
        instruction = dna[index] >> 6  # extracts only first 2 numbers from byte
        address = dna[index] & 63  # AND operation over 00111111 = extracts last 6 numbers from byte
        if instruction == 0:
            dna[address] += 1
            index += 1
        elif instruction == 1:
            dna[address] -= 1
            index += 1
        elif instruction == 2:
            index = address
        elif instruction == 3:
            move = movement(dna[index])
            moves.append(move)
            index += 1
        if index > 63:  # If index is bigger than allowed, go again from start
            index = 0
    return moves  # returns array of moves


def movement(value):  # Move according to last 2 numbers in value
    temp = value & 3
    if temp == 0:
        return 'H'
    elif temp == 1:
        return 'D'
    elif temp == 2:
        return 'P'
    elif temp == 3:
        return 'L'


def set_fitness(
        individual):  # set fitness for individual, increasing drastically by number of found treasures, decreasing for path length
    if individual.treasures != 0:
        individual.fitness = 1024 * int(individual.treasures) - len(
            individual.path)  # max path = 500, 1 treasure > 0 treasure with low path => 1024
    else:
        individual.fitness = 512 - len(individual.path)


def deathmatch(generation, k):  # game to pick individual with the highest fitness
    fighters = []
    for i in range(int(k)):
        fighters.append(random.choice(generation))
    return max(fighters, key=attrgetter('fitness'))


def mating(individual1, individual2):  # changing DNA of 2 individuals
    index = random.randint(len(individual1.dna) // 3,
                           (len(individual1.dna) // 3) * 2)  # cut dna somewhere between 1/3 and 2/3 of DNA
    new_dna1 = []
    new_dna2 = []
    for i in range(len(individual1.dna)):  # exchange halves of individual´s DNA depending on index
        if i <= index:
            new_dna1.append(individual2.dna[i])
            new_dna2.append(individual1.dna[i])
        else:
            new_dna1.append(individual1.dna[i])
            new_dna2.append(individual2.dna[i])
    new_individual1 = Individual(new_dna1, get_path(new_dna1), 0, 0)
    new_individual2 = Individual(new_dna2, get_path(new_dna2), 0, 0)
    return new_individual1, new_individual2


def roulette(generation, k):  # game to pick random individual winner
    fighters = []
    fighter_fitness = []
    pool = 0  # sum of all fitness of fighters
    for i in range(int(k)):  # appends fighters and their fitness to arrays
        temp = random.choice(generation)
        fighters.append(temp)
        fighter_fitness.append(temp.fitness)
        pool += temp.fitness
    pick = random.randint(0, pool)  # picks random number from pool
    for i in range(
            len(fighters)):  # finds whose fighter´s number was picked (more fitness = bigger chance of being picked)
        if fighter_fitness[i] < pick:
            pick -= fighter_fitness[i]
        elif fighter_fitness[i] >= pick:
            return fighters[i]


def check_map(individual, position, treasures,
              size):  # function to check if human didn't go away from map, if not, if he found treasure
    column = position[0]
    row = position[1]
    if size > column >= 0 and size > row >= 0:
        for treasure in treasures:
            if column == treasure[0] and row == treasure[1]:
                individual.treasures += 1
                treasures.remove(treasure)
        return True
    return False


def finding_treasures(start, treasures, individual, size):  # going through path of individual
    position = start.copy()
    step_count = 0  # Variable to track the number of treasures found

    for step in individual.path:
        if individual.treasures == 5:
            individual.path=individual.path[:step_count]
            break
        if step == 'P':
            position[0] += 1
        elif step == 'L':
            position[0] -= 1
        elif step == 'H':
            position[1] -= 1
        elif step == 'D':
            position[1] += 1
        step_count += 1
        if not check_map(individual, position, treasures,
                         size):  # check if he found treasure or went away from map
            break


def visualize_path(size, individual, treasures, start_pos, speed=25): #Generated by ChatGPT
    window = tk.Tk()
    window.title("Path Visualization")

    # Increase square size to 100
    square_size = 100

    canvas = tk.Canvas(window, width=size * square_size, height=size * square_size)
    canvas.pack()

    position = start_pos  # Start in the middle of the canvas
    visited_positions = set()

    def draw_map():
        for x in range(size):
            for y in range(size):
                if [x, y] in treasures:
                    canvas.create_rectangle(x * square_size, y * square_size, (x + 1) * square_size,
                                            (y + 1) * square_size, fill='gold')
                else:
                    canvas.create_rectangle(x * square_size, y * square_size, (x + 1) * square_size,
                                            (y + 1) * square_size, fill='white')

    def move_one_step():
        nonlocal position
        nonlocal visited_positions

        # Draw the map at the beginning
        if len(visited_positions) == 0:
            draw_map()

        step = individual.path.pop(0)

        if step == 'P':
            new_position = (position[0] + 1, position[1])
        elif step == 'L':
            new_position = (position[0] - 1, position[1])
        elif step == 'H':
            new_position = (position[0], position[1] - 1)
        elif step == 'D':
            new_position = (position[0], position[1] + 1)

        # Ensure the new position is within the map bounds
        if 0 <= new_position[0] < size and 0 <= new_position[1] < size:
            position = new_position

        visited_positions.add(tuple(position))

        for treasure in treasures:
            if tuple(position) == tuple(treasure):
                # Change the color of the visited treasure to black
                canvas.create_rectangle(position[0] * square_size, position[1] * square_size,
                                        (position[0] + 1) * square_size, (position[1] + 1) * square_size, fill='black')
                treasures.remove(list(position))

        # Draw the current position as red
        canvas.create_rectangle(position[0] * square_size, position[1] * square_size, (position[0] + 1) * square_size,
                                (position[1] + 1) * square_size, fill='red')

        # Restore previously visited positions to white
        for visited in visited_positions:
            if visited != position:
                canvas.create_rectangle(visited[0] * square_size, visited[1] * square_size,
                                        (visited[0] + 1) * square_size, (visited[1] + 1) * square_size, fill='white')

        window.update()

        if len(individual.path) > 0:
            window.after(speed, move_one_step)

    move_one_step()
    window.mainloop()

def best_fitness(population):#function to check maximum fitness in current generation
    best=-1
    for human in population:
        if human.fitness>best:
            best=human.fitness
    return best

# Start
population = []
treasure_list = []
generations_number = input('Number of generations:')
population_size = input('Size of population:')
best_decider = input('deathmatch (1) or roulette (2): ')
decider_num = 100000000
while int(decider_num) > int(population_size) or int(decider_num) == int(population_size) or int(decider_num)<1:
    decider_num = input('how many individuals put into decider:')
    if int(decider_num) > int(population_size) or int(decider_num) == int(population_size) or int(decider_num)<1:
        print("Invalid input, number of individuals cannot be more or equal than population size!")

size = get_size()
start_coords = get_start_coordinates()
get_treasure_coordinates(treasure_list)
number_of_treasures = len(treasure_list)
best_individual = None
best_individual_gen = 0

for indiv in range(int(population_size)):  # append each individual to starting population
    human = make_individual()
    individual = Individual(human, get_path(human), 0, 0)
    population.append(individual)

is_true = False
best_fitness_in_generations=[]
for i in range(int(generations_number)):  # for loop in number of generations
    gen = i
    for human in population:  # go through each individual
        start = start_coords.copy()
        treasures = treasure_list.copy()
        finding_treasures(start, treasures, human, size)  # find out how many treasures individual found
        set_fitness(human)
        if human.treasures == number_of_treasures:  # if found all, end program
            print("Human from " + str(i) + " generation found all treasures, his path was:")
            print(human.path)
            best_fitness_in_generations.append(human.fitness)
            visualize_path(size, human, treasure_list, start_coords, speed=500)
            is_true = True
            break
        else:  # if didn't find all, find it´s fitness and check if he is the best individual yet
            if best_individual is None or human.treasures > best_individual.treasures:
                best_individual = human
                best_individual_gen = gen
    if is_true:
        break
    else:  # if we didn't find individual that found all treasures, create new population
        new_generation = []  # array of new generation
        for k in range((int(len(population)+1) // 2)):  # for loop that makes new children from best parents and appends to new_generation
            while True:
                if best_decider == "1":
                    individual1 = deathmatch(population, decider_num)
                    individual2 = deathmatch(population, decider_num)
                    if individual1 is not individual2:  # while loop to find 2 different individuals
                        break
                elif best_decider == "2":
                    individual1 = roulette(population, decider_num)
                    individual2 = roulette(population, decider_num)
                    if individual1 is not individual2:
                        break
            children = mating(individual1, individual2)
            for i in range(2):
                mutate(children[i])
                if(len(new_generation)<int(population_size)):
                    new_generation.append(children[i])
        best_fitness_in_generations.append(best_fitness(population))
        population.clear()
        population.extend(new_generation)
        #print(len(population))
# forloop creates 2 child from best parents, then rest of new population is made by mating individuals from the new population only!

if not is_true:
    print("Solution for all treasures not found, but best individual was from " + str(
        best_individual_gen) + " generation and found", best_individual.treasures, "treasure/s")
    print("His path was: ", best_individual.path)
    visualize_path(size, best_individual, treasure_list, start_coords, speed=500)

plt.plot(best_fitness_in_generations)
plt.title('Best Fitness in Each Generation')
plt.xlabel('Generation')
plt.ylabel('Best Fitness')
plt.show()