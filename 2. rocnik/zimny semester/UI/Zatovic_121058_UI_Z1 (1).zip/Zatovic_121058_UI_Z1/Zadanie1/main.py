import copy
import random
import time


class Node:
    def __init__(self, data, level, fval, parent=None):
        self.data = data  # list of current situation of the puzzle
        self.level = level  # how many times was the blank moved until this position
        self.fval = fval  # fvalue of current Node
        self.parent = parent  # parent Node of current Node

    def findBlank(self, input):  # function to find blank in current Node data
        for i in range(0, len(self.data)):
            for j in range(0, len(self.data[0])):
                if input[i][j] == "_":
                    return i, j

    def moveBlank(self, input, y1, x1, y2, x2):  # x = column y = row // function to move blank in given direction
        if (x2 >= 0 and x2 < len((self.data[0])) and (y2 >= 0 and y2 < (len(self.data)))):
            tempInput = input
            temp = tempInput[y2][x2]
            tempInput[y2][x2] = tempInput[y1][x1]
            tempInput[y1][x1] = temp
            return tempInput
        else:
            return None

    def childMaker(self):
        y, x = self.findBlank(self.data)
        valList = [[y, x - 1], [y, x + 1], [y - 1, x], [y + 1, x]]  # List of all possible direction blank can move
        children = []
        for i in valList:
            child = self.moveBlank(copy.deepcopy(self.data), y, x, i[0],
                                   i[1])  # creates child with blank moving in specific direction
            if child is not None:  # blank didnt move out of the list
                childNode = Node(child, self.level + 1, 0,
                                 self)  # creates Node with that child, level is 1 bigger than parent
                children.append(childNode)
        return children


class Puzzle:
    def __init__(self):
        self.m = 0
        self.n = 0
        self.openNodes = []
        self.closedNodes = []
        self.visitedNodes = set()  # to see what Nodes we already visited, good to see if program doesn't cycle

    def userInput(self):  # function to work with user inputs
        uInput = []
        flatInput = []
        for k in range(0, (self.n * self.m)):  # make a list with all the values on input
            flatInput.append(input())
        for i in range(0, (self.n * self.m), self.m):  # divide a flat list into list of lists in groups of m
            sublist = flatInput[i:i + self.m]
            uInput.append(sublist)
        return uInput
    def f(self, start, goal):
        return self.h(start.data, goal) + start.level  # f(x) = h(x) + g(x)
    def h(self, start,
          goal):  # function to calculate the different between puzzles - numbers on different positions than in goal state
        temp = 0
        for i in range(0, self.n):
            for j in range(0, self.m):
                if start[i][j] != goal[i][j] and start[i][j] != "_":
                    temp += 1
        return temp
    def f2(self, start, goal):
        return self.h2(start.data, goal)
    def h2(self, start, goal):  # how far each node is from final state position
        temp = 0
        for i in range(0, self.n):
            for j in range(0, self.m):
                if start[i][j] != goal[i][j] and start[i][j] != "_":
                    for k in range(0, self.n):
                        for h in range(0, self.m):
                            if start[i][j] == goal[k][h]:
                                temp += abs(i - k) + abs(j - h)
        return temp
    def generate_states(self, k):  # Function to create random inputs, this code was written by CHATGPT!
        instances2x2=[
            [
                ['1','2'],
                ['3','_']
            ],
            [
                ['_','1'],
                ['3','2']
            ]
        ]
        instances3x2 = [
            [
                ['1', '2','3'],
                ['4', '_','5']
            ],
            [
                ['4', '_','1'],
                ['5', '3','2']
            ]
        ]
        instances3x3 = [
            [
                ['1', '2', '3'],
                ['4', '5', '6'],
                ['7', '8', '_']
            ],
            [
                ['1', '2', '3'],
                ['4', '6', '8'],
                ['7', '5', '_']
            ]
        ]

        instances4x4 = [
            [
                ['1', '2', '3', '4'],
                ['5', '6', '7', '8'],
                ['9', '10', '11', '12'],
                ['13', '14', '15', '_']
            ],
            [
                ['1', '_', '2', '3'],
                ['5', '6', '7', '4'],
                ['9', '10', '11', '8'],
                ['13', '14', '15', '12']
            ]
        ]

        instances4x3 = [
            [
                ['1', '3', '5'],
                ['7', '9', '11'],
                ['_', '2', '4'],
                ['6', '8', '10'],
            ],
            [
                ['_', '9', '3'],
                ['1', '7', '5'],
                ['2', '4', '11'],
                ['6', '8', '10']
            ]
        ]
        return instances2x2,instances3x2,instances3x3,instances4x4,instances4x3
    def gameType(self):
        print("manual or automatic input of states? m (manual) / a (automatic)")
        what = input()
        if (what == "m"):
            print("Number of columns")
            self.m=int(input())
            print("Number of rows")
            self.n=int(input())
            print("Start state:  \n")
            start_state = self.userInput()
            print("Goal state: \n")
            goal = self.userInput()
            number = 1
            return start_state, goal, number, None
        elif (what == "a"):
            number = 5
            instances2x2, instances3x2,instances3x3,instances4x4,instances4x3 = self.generate_states(number)
            statelist=[]
            statelist.append(instances2x2)
            statelist.append(instances3x2)
            statelist.append(instances3x3)
            statelist.append(instances4x4)
            statelist.append(instances4x3)
            return None, None, number, statelist
    def gameProcess(self):
        start_state,goal,number, statelist = self.gameType()
        for k in range(number):
            print("Test " + str(k + 1))
            solv = True
            if(statelist!=None):
                start_state = statelist[k][0]
                goal = statelist[k][1]
                self.n = len(start_state)
                self.m = len(start_state[0])

            if (self.m == 3 and self.n == 3):
                solv = self.is_solvable(start_state, goal)
            if (solv == True):
                for k in range(2):
                    self.openNodes = []
                    self.closedNodes = []
                    self.visitedNodes = set()
                    if k == 1:
                        start_time = time.time()
                        print("heuristic 1")
                        start_Node = Node(start_state, 0, 0)
                        start_Node.fval = self.f(start_Node, goal)
                        self.openNodes.append(start_Node)  # Start node put into open list
                        # while len(self.visitedNodes)<100000:
                        while True:
                            self.openNodes.sort(key=lambda node: node.fval)  # usporiadanie od najmensieho fvalue
                            if not self.openNodes:  # if there's nothing left in openNodes, end (cycling)
                                print("The puzzle is unsolvable.")
                                break
                            cur = self.openNodes[0]  # first explores childs with lowest f values
                            if (self.h(cur.data, goal) == 0):
                                print("The puzzle is solvable.")
                                #self.printPath(cur)  # Print the path
                                break
                            for i in cur.childMaker():
                                i.fval = self.f(i, goal)  # zistenie fvalue childov
                                if tuple(map(tuple, i.data)) not in self.visitedNodes:
                                    self.openNodes.append(i)
                                    self.visitedNodes.add(tuple(map(tuple, i.data)))
                            self.closedNodes.append(cur)  # danie current node do closed listu
                            del self.openNodes[0]  # odstranenie current node z openlistu
                        if (len(self.visitedNodes) >= 100000):
                            print("Too many iterations. Terminating")
                        end_time = time.time()
                        elapsed_time = end_time - start_time
                        print("visited nodes:" + str(len(self.visitedNodes)))
                        print(f"Total time taken: {elapsed_time * 1000} miliseconds\n")

                    elif k == 0:
                        start_time = time.time()
                        self.visitedNodes = set()
                        self.openNodes = []
                        self.closedNodes = []
                        print("heuristic 2")
                        start_Node = Node(start_state, 0, 0)
                        start_Node.fval = self.f2(start_Node, goal)
                        self.openNodes.append(start_Node)  # Start node put into open list
                        # while len(self.visitedNodes)<100000:
                        while True:
                            self.openNodes.sort(
                                key=lambda node: node.fval)  # usporiadanie Nodov v openNodes od najmensieho fvalue
                            if not self.openNodes:
                                print("The puzzle is unsolvable.")
                                break
                            cur = self.openNodes[0]  # first explores childs with lowest f values
                            if (self.h2(cur.data, goal) == 0):
                                print("The puzzle is solvable.")
                                self.printPath(cur)  # Print the path
                                break
                            for i in cur.childMaker():
                                i.fval = self.f2(i, goal)  # zistenie fvalue childov
                                if tuple(map(tuple, i.data)) not in self.visitedNodes:
                                    self.openNodes.append(i)
                                    self.visitedNodes.add(tuple(map(tuple, i.data)))
                            self.closedNodes.append(cur)  # danie current node do closed listu
                            del self.openNodes[0]  # odstranenie current node z openlistu
                        if (len(self.visitedNodes) >= 100000):
                            print("Too many iterations. Terminating")
                        end_time = time.time()
                        elapsed_time = end_time - start_time
                        print("visited nodes:" + str(len(self.visitedNodes)))
                        print(f"Total time taken: {elapsed_time * 1000} miliseconds\n")
                    elif k == 2:
                        break
            else:
                print("The puzzle is unsolvable.")
            print("\n")
        print("All done")
    def printPath(self, node):  # THIS CODE WAS WRITTEN BY CHATGPT!
        path = []
        while node is not None:
            path.append(node.data)
            node = node.parent
        path.reverse()
        for step, state in enumerate(path):
            print(f"Step {step + 1}:")
            for row in state:
                print(" ".join(row))
            print()
    def is_solvable(self, start, goal):  # THIS CODE WAS WRITTEN BY CHATGPT AND HELP OF GEEKSFORGEEKS
        def count_inversions(arr):
            inversions = 0
            for i in range(len(arr)):
                for j in range(i + 1, len(arr)):
                    if arr[i] > arr[j]:
                        inversions += 1
            return inversions

        # Flatten the puzzles (exclude the blank tile)
        flat_puzzle = [tile for row in start for tile in row if tile != "_"]
        flat_goal = [tile for row in goal for tile in row if tile != "_"]

        # Count inversions
        inversions_puzzle = count_inversions(flat_puzzle)
        inversions_goal = count_inversions(flat_goal)

        # Check parity
        parity_puzzle = inversions_puzzle % 2
        parity_goal = inversions_goal % 2

        # Compare parities
        return parity_puzzle == parity_goal


puzzle = Puzzle()
puzzle.gameProcess()