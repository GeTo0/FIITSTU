PIDs = {
    8192: "CDP",
    8196: "DTP",
    267: "PVSTP+",
    2203: "AppleTalk"
}

SAPs = {
    0: "Null SAP",
    2: "LLC Sublayer Management / Individual",
    3: "LLC Sublayer Management / Group",
    6: "IP",
    14: "PROWAY Network Management, Maintenance and Installation",
    78: "MMS",
    94: "ISI IP",
    126: "X.25 PLP",
    142: "PROWAY Active Station List Maintenance",
    170: "SNAP",
    224: "IPX",
    244: "LAN Management",
    254: "ISO Network Layer Protocols",
    255: "Global DSAP",
    240: "NETBIOS",
    66: "STP",
}

APPprotocols = {
    20:'FTP-DATA',
    21:'FTP-CONTROL',
    22:'SSH',
    23:'TELNET',
    25:'SMTP',
    37: "TIME",
    53: "DNS",
    67: "DHCP",
    68: "DHCP",
    69: "TFTP",
    80:'HTTP',
    110: "POP3",
    119: "NNTP",
    137: "NETBIOS-NS",
    139:'NETBIOS-SSN',
    143: "IMAP",
    179: "BGP",
    389: "LDAP",
    443:'HTTPS',
    1900: "SSDP",
    161:"SNMP",
    162: "SNMP-TRAP",
    514:"SYSLOG",
    520:"RIP",
    666:"DB-LSP-DISC",
    5353: "MDNS"
}

Protocols = {
    "06":'TCP',
    "11":'UDP',
    "01":'ICMP',
    "02":'IGMP'
}

EtherTypes={
    "0800": "IPV4",
    "0806": "ARP",
    "86dd": "IPV6",
    "88cc": "LLDP"
}

icmpTypes={
    "00": "Echo reply",
    "08": "Echo request",
    "03": "Destination unreachable",
    "0b": "Time exceeded"
}